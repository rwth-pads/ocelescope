from typing import Literal
from uuid import uuid4

from ocelescope import Resource
from ocelescope.visualization import DotVis, SVGVis
from pydantic import BaseModel, Field, NonNegativeInt, model_validator

from ..util.QuantityNet import QuantityNet


def generate_id() -> str:
    return str(uuid4())


class BaseElement(BaseModel):
    id: str = Field(default_factory=generate_id)
    name: str = ""
    label: str | None = None
    properties: dict | None = None
    input: set[str] = Field(default_factory=set)
    output: set[str] = Field(default_factory=set)

    @model_validator(mode="after")
    def set_defaults(self):
        if self.name == "":
            self.name = self.id
        return self


class Place(BaseElement):
    marking: NonNegativeInt = 0
    initial: bool | None = None
    final: bool | None = None
    object_type: str

    @model_validator(mode="after")
    def set_defaults(self):
        if self.initial is None:
            self.initial = len(self.input) == 0

        if self.final is None:
            self.final = len(self.output) == 0

        return self


class Transition(BaseElement):
    handover: bool = False
    variable_places: set[str] = Field(default_factory=set)
    dummy: bool = False
    silent: bool


class DecouplingPoint(Place):
    marking: NonNegativeInt = 0
    object_type: str
    dummy: bool = True


class Arc(BaseModel):
    id: str = Field(default_factory=generate_id)
    name: str = ""
    label: str | None = None
    properties: dict | None = None
    source: Place | Transition
    target: Place | Transition
    variable: bool | None

    @property
    def place(self) -> Place:
        if isinstance(self.source, Place):
            return self.source
        else:
            return self.target

    @property
    def transition(self) -> Transition:
        if isinstance(self.target, Transition):
            return self.target
        else:
            return self.source

    @property
    def object_type(self) -> str:
        """Returns the object type of the place connected to this arc."""
        return self.place.object_type  #


def find_element(elements, element_id):
    return next((e for e in elements if str(element_id) == e.id), None)


class QNet(Resource):
    label = "Qnet"
    description = ""
    legacy_label: str | None
    properties: dict | None = None
    places: list[Place] = Field(default_factory=list)
    transitions: list[Transition] = Field(default_factory=list)
    decoupling_points: list[DecouplingPoint] = Field(default_factory=list)
    arcs: list[Arc] = Field(default_factory=list)
    item_type: str

    @classmethod
    def from_legacy_net(cls, qnet: QuantityNet, item_type: str):
        converted_qnet = cls(legacy_label=qnet.label, properties=qnet.properties, item_type=item_type)

        for transition in qnet.transitions:
            converted_qnet.transitions.append(
                Transition(
                    id=str(transition.id),
                    name=str(transition.name),
                    label=transition.label,
                    silent=transition.silent,
                    properties=transition.properties,
                    output=set([str(output.id) for output in transition.outputs]),
                    input=set([str(input.id) for input in transition.inputs]),
                    handover=transition.handover,
                    dummy=transition.dummy,
                    variable_places=set([str(place.id) for place in transition.variable_places]),
                )
            )

        for place in qnet.places:
            converted_qnet.places.append(
                Place(
                    id=str(place.id),
                    name=str(place.name),
                    label=place.label,
                    properties=place.properties,
                    object_type=place.object_type,
                    output=set([str(output.id) for output in place.outputs]),
                    input=set([str(input.id) for input in place.inputs]),
                    final=place.final,
                    marking=place.marking or 0,
                    initial=place.initial,
                )
            )

        for dp in qnet.decoupling_points:
            converted_qnet.decoupling_points.append(
                DecouplingPoint(
                    id=str(dp.id),
                    name=str(dp.name),
                    label=dp.label,
                    properties=dp.properties,
                    output=set([str(output.id) for output in dp.outputs]),
                    input=set([str(input.id) for input in dp.inputs]),
                    object_type=dp.object_type,
                    dummy=dp.dummy,
                )
            )

        for arc in qnet.get_arcs():
            source = (
                find_element(converted_qnet.places, arc.source.id)
                or find_element(converted_qnet.transitions, arc.source.id)
                or find_element(converted_qnet.decoupling_points, arc.source.id)
            )

            target = (
                find_element(converted_qnet.places, arc.target.id)
                or find_element(converted_qnet.transitions, arc.target.id)
                or find_element(converted_qnet.decoupling_points, arc.target.id)
            )

            if source and target:
                converted_qnet.arcs.append(
                    Arc(
                        source=source,
                        name=arc.name,
                        properties=arc.properties,
                        label=arc.label,
                        target=target,
                        variable=arc.variable,
                    )
                )

            if source is None or target is None:
                print(f"Missing source or target for arc: {arc}")
                print(f"Available places: {[p.id for p in converted_qnet.places]}")
                print(f"Available transitions: {[t.id for t in converted_qnet.transitions]}")

        return converted_qnet

    @property
    def object_types(self):
        return {place.object_type for place in self.places + self.decoupling_points}

    def visualize(self) -> DotVis | None:
        from ..util.QnetGraph import QuantityGraph

        graph = QuantityGraph(qnet=self, black_object_type=self.item_type, dummy_silent=True, marked=True)

        graph.create_graph()

        if graph.graph is None:
            return None

        return DotVis(type="dot", dot_str=graph.graph.source, layout_engine="dot")
