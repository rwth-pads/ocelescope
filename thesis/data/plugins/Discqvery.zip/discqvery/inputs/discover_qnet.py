from __future__ import annotations


from ocelescope import COMPUTED_SELECTION, OCEL, PluginInput
from ..extensions.quantity import QuantityExtension
from ..util.GLOBAL import QEL_ITEM_TYPE


class DiscoverQnetInput(PluginInput, frozen=True):
    item_type: str = COMPUTED_SELECTION(
        title="Item Type",
        description="The item type for which the qnet should be generated",
        provider="item_type_provider",
    )

    @staticmethod
    def item_type_provider(ocel: OCEL):
        extension = ocel.get_extension(QuantityExtension)

        if extension is None or extension.oqty is None:
            return []

        return extension.oqty[QEL_ITEM_TYPE].unique().tolist()
