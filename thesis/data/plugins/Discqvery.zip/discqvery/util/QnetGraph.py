from graphviz import Digraph
from typing import Any, Optional
from abc import ABC

from ..resources.qnet import QNet, Transition, Place, Arc
from .GLOBAL import CHART_COLOURS


class GraphElement:
    def __init__(self, id: Any, name: str = None, obj_label: str = None):
        self.id = id
        self.name = name if name else ""
        self.obj_label = obj_label if obj_label else ""


class NodeTemplate(GraphElement, ABC):
    def __init__(self, id: Any, name: str = None, obj_label: str = None):
        super().__init__(id=id, name=name, obj_label=obj_label)
        self.style = "filled"
        self.height = 0.5
        self.width = 0.5
        self.fixedsize = "true"
        self.shape = "ellipse"
        self.class_name = ""
        self.penwidth = 1.0
        self.color = "black"
        self.fillcolor = "white"
        self.display_label = False
        self.fontname = "Arial"
        self.fontsize = 12
        self.fontcolor = "black"


class PlaceNode(NodeTemplate):
    def __init__(
        self,
        color: str,
        id: Any,
        class_name: str,
        initial_object_type: str = None,
        name: str = None,
        obj_label: str | int = None,
        display_label: bool = False,
    ):
        super().__init__(id=id, name=name, obj_label=obj_label)
        self.shape = "circle"
        self.class_name = class_name
        self.fillcolor = f"{color}70" if color != "black" else "white"
        self.penwidth = 1.0
        self.color = color
        self.display_label = display_label

class DecouplingPointNode(NodeTemplate):

    def __init__(
        self,
        id: Any,
        name: str,
        obj_label: str | int = "",
        color: str | None = None,
        display_label: bool = True
    ):
        super().__init__(id=id, name=name, obj_label=obj_label)
        self.shape = "triangle"
        self.class_name = "DecouplingPoint"
        self.fillcolor = "white"
        self.penwidth = 2
        self.color = "black" if color == None else color
        self.display_label = display_label
        self.label = None
        self.fixedsize = True
        self.height = 0.75  # Increase the height
        self.width = 0.75  # Increase the width
        self.xlabel = f"{obj_label}" if self.display_label else ""


class TransitionNode(NodeTemplate):
    def __init__(self, id: Any, obj_label: str, name: str = None, color: Optional[str] = None):
        super().__init__(id=id, name=name, obj_label=obj_label)
        self.shape = "rectangle"
        self.class_name = "Transition"
        self.fillcolor = "white" if not color else f"{color}30"
        self.penwidth = 1.0
        self.color = "black" if not color else color
        self.display_label = True
        self.fixedsize = "false"


class SilentTransitionNode(TransitionNode):
    def __init__(self, id: Any, obj_label: str, name: str = None):
        super().__init__(id=id, name=name, obj_label=obj_label)
        self.display_label = False
        self.fillcolor = "#00000040"
        self.width = 0.1


class DummyTransitionObjectTypeNode(TransitionNode):
    def __init__(self, id: Any, obj_label: str, name: str = None, color: Optional[str] = None):
        super().__init__(id=id, name=name, obj_label=obj_label)
        self.display_label = False
        self.fillcolor = "#00000040" if not color else f"{color}30"
        self.color = "black" if not color else color
        self.width = 0.1


class EdgeTemplate(GraphElement, ABC):
    def __init__(
        self,
        id: Any,
        source_id: str,
        target_id: str,
        name: str = None,
        obj_label: str = None,
    ):
        super().__init__(id=id, name=name, obj_label=obj_label)
        self.style = "solid"
        self.fontname = "Arial"
        self.fontsize = 10
        self.fontcolor = "black"
        self.class_name = ""
        self.penwidth = 1.0
        self.color = "black"
        self.display_label = False
        self.source_id = source_id
        self.target_id = target_id


class ArcEdge(EdgeTemplate):
    def __init__(
        self,
        id: Any,
        color: str,
        source_id: str,
        target_id: str,
        name: str = None,
        obj_label: str = None,
    ):
        super().__init__(
            id=id,
            name=name,
            obj_label=obj_label,
            source_id=source_id,
            target_id=target_id,
        )
        self.class_name = "ObjectArc"
        self.penwidth = 1.0
        self.color = color
        self.display_label = True


class VariableObjectArcEdge(EdgeTemplate):
    def __init__(
        self,
        id: Any,
        color: str,
        source_id: str,
        target_id: str,
        name: str = None,
        obj_label: str = None,
    ):
        super().__init__(
            id=id,
            name=name,
            obj_label=obj_label,
            source_id=source_id,
            target_id=target_id,
        )
        self.class_name = "ObjectArc"
        self.penwidth = 3
        self.color = color
        self.display_label = False
        self.style = "bold"


class GraphTemplate(GraphElement):
    def __init__(self, id: Any, obj_label: str = None, name: str = None):
        super().__init__(id=id, name=name, obj_label=obj_label)
        self.orientation = "H"
        self.direction = "LR"
        self.directed = True


class QuantityGraph(GraphTemplate):
    none_graphviz_attribute_names = [
        "obj_label",
        "display_label",
        "source_id",
        "target_id",
        "id",
    ]

    def __init__(
        self,
        qnet: QNet,
        name: str = None,
        id: Any = None,
        marked: bool = False,
        obj_label: str = None,
        black_object_type: str = None,
        dummy_silent=False,
        coloured_dummies: bool = False,
    ):
        super().__init__(id=id, name=name, obj_label=obj_label)
        self.transitions = set()
        self.object_places = set()
        self.collection_points = set()
        self.decoupling_points = set()
        self.object_arcs = set()
        self.quantity_arcs = set()
        self.graph = None
        self.relevant_object_types = qnet.object_types

        if black_object_type:
            self.relevant_object_types.discard(black_object_type)
        else:
            self.relevant_object_types = qnet.object_types

        relevant_colors = CHART_COLOURS[: len(self.relevant_object_types)]
        self.color_scheme = dict(zip(list(self.relevant_object_types), relevant_colors))
        if black_object_type:
            self.color_scheme[black_object_type] = "black"

        self.create_transition_nodes(qnet.transitions, dummy_silent, coloured_dummies)
        self.create_object_place_nodes(qnet.places, marked=marked)
        self.create_dp_nodes(qnet.decoupling_points)
        self.create_object_arc_edges(qnet.arcs)

    def create_transition_nodes(
        self,
        transition_objects: set[Transition],
        dummy_silent: bool = False,
        coloured_dummies: bool = False,
    ):
        for transition in transition_objects:
            if dummy_silent and transition.dummy:
                if coloured_dummies:
                    node = DummyTransitionObjectTypeNode(
                        id=transition.name,
                        name=transition.name,
                        obj_label=transition.label,
                        color=self.color_scheme[transition.properties["object_type"]],
                    )
                else:
                    node = SilentTransitionNode(
                        id=transition.name,
                        name=transition.name,
                        obj_label=transition.label,
                    )
                self.transitions.add(node)
                continue

            if transition.silent:
                node = SilentTransitionNode(id=transition.name, name=transition.name, obj_label=transition.label)
            elif transition.handover:
                node = TransitionNode(id=transition.name, name=transition.name, obj_label=transition.label)
            else:
                node = TransitionNode(
                    id=transition.name,
                    name=transition.name,
                    obj_label=transition.label,
                    color=self.color_scheme[transition.properties["object_type"]],
                )
            self.transitions.add(node)

    def create_object_place_nodes(self, object_places: set[Place], marked: bool = False):
        for place in object_places:
            initial = place.object_type if place.initial else None
            obj_label = place.marking if marked else ""
            display = marked
            node = PlaceNode(
                id=place.name,
                name=place.name,
                obj_label=obj_label,
                display_label=display,
                color=self.color_scheme[place.object_type],
                initial_object_type=initial,
                class_name=place.object_type,
            )
            self.object_places.add(node)

    def create_dp_nodes(self, dps: set[Place]):
        for dp in dps:
            node = DecouplingPointNode(
                id=dp.name,
                name=dp.name,
                obj_label=dp.label,
                color=self.color_scheme[dp.object_type],
                display_label= False if dp.dummy else True
            )
            self.decoupling_points.add(node)

    def create_object_arc_edges(self, object_arcs: list[Arc]):
        for arc in object_arcs:
            if arc.variable:
                edge = VariableObjectArcEdge(
                    id=arc.name,
                    name=arc.name,
                    obj_label=arc.label,
                    color=self.color_scheme[arc.object_type],
                    source_id=arc.source.name,
                    target_id=arc.target.name,
                )
            else:
                edge = ArcEdge(
                    id=arc.name,
                    name=arc.name,
                    obj_label=arc.label,
                    color=self.color_scheme[arc.object_type],
                    source_id=arc.source.name,
                    target_id=arc.target.name,
                )
            self.object_arcs.add(edge)

    def clear_graph(self):
        self.graph = None

    def create_graph(self):
        self.clear_graph()
        self.graph = Digraph(name="QuantityGraph", format="dot")
        self.graph.attr(rankdir="LR", ratio="0.35")
        self.add_nodes_to_graph()
        self.add_edges_to_graph()

    def add_nodes_to_graph(self):
        for node in self.transitions | self.object_places | self.decoupling_points:
            attributes = vars(node).copy()
            node_id = str(node.id)

            # Ensure all attribute values are strings and handle missing 'label'
            display_label = attributes.get("display_label", False)
            obj_label = attributes.get("obj_label", "")
            attributes["label"] = str(obj_label) if display_label else ""

            for none_attr in self.none_graphviz_attribute_names + ["name"]:
                attributes.pop(none_attr, None)

            # Convert remaining attributes to strings
            attributes = {k: str(v) for k, v in attributes.items() if v is not None}

            self.graph.node(node_id, **attributes)

    def add_edges_to_graph(self):
        for edge in self.object_arcs:
            attributes = vars(edge).copy()
            source_id = str(edge.source_id)
            target_id = str(edge.target_id)

            # Ensure all attribute values are strings and handle missing 'label'
            display_label = attributes.get("display_label", False)
            obj_label = attributes.get("obj_label", "")
            attributes["label"] = str(obj_label) if display_label else ""

            for none_attr in self.none_graphviz_attribute_names + ["name"]:
                attributes.pop(none_attr, None)

            # Convert remaining attributes to strings
            attributes = {k: str(v) for k, v in attributes.items() if v is not None}

            self.graph.edge(source_id, target_id, **attributes)

    def get_string_representation(self) -> str:
        if not self.graph:
            self.create_graph()
        return self.graph.pipe(format="dot").decode("utf-8")
