from collections import Counter
from typing import Dict, Any, List, Optional
from .GLOBAL import DUMMY_ITEM_TYPE, item_type_active_evaluation


class Qounter(Counter):
    """
    A Counter that can be used to count quantities of items.
    Slight adaptations to the Counter class, e.g. for two counter c1 and c2:
        - Calling "c1 + c2" will return a new Counter with the sum of both, also including negative and zero counts (original counter removes negative counts).
        - Calling "c1 - c2" will return a new Counter with the difference of both, also including negative and zero counts (original counter removes negative counts).
        - Calling sum([c1, c2]) will return a new Counter with the sum of all counters in the list, also including negative and zero counts.
        - Calling abs(c1) will return a new Counter with the absolute values of all counts.
        - Calling bool(c1) will return True if the Counter is non-empty, i.e., contains at least one item with a non-zero count.
    """

    def __add__(self, other: "Qounter"):
        new = self.copy()
        new.update(other)
        return new

    def __sub__(self, other: "Qounter"):
        new = self.copy()
        new.subtract(other)
        return new

    def __radd__(self, other: "Qounter"):
        if other == 0:
            return self
        return self.__add__(other)

    def __pos__(self):
        return Qounter(super().__pos__())

    def __neg__(self):
        new = Qounter() - super().__neg__()
        return new

    def __abs__(self):
        return Qounter({item_type: abs(count) for item_type, count in dict(self).items()})

    def __bool__(self):
        """
        Returns True if the Counter is non-empty, i.e., contains at least one item with a non-zero count.
        """
        return any(count != 0 for count in self.values())

    def elements(self):
        """
        Returns an iterator over elements repeating each as many times as its count.
        """
        return list(dict(self).keys())

    @property
    def item_types(self):
        """
        Returns a list of all item types in the Counter.
        """
        return self.elements()

    @property
    def active_item_types(self):
        """
        Returns a list of all item types that have a non-zero count.
        """
        return list(key for key, value in self.items() if item_type_active_evaluation(value=value))

    def positive_counterpart(self):
        """
        Returns a Counter with only the positive counts.
        """
        return self.__pos__

    def negative_counterpart(self):
        """
        Returns a Counter with only the negative counts.
        """
        return self.__neg__()


class MultiQounter(Dict):
    """
    An object where a Counter is assigned to each counter in a set.
    This allows for the aggregation of multiple counters, e.g. for different objects.
    It supports addition and subtraction of counters, as well as the aggregation of multiple counters.
    """

    def __init__(self, data=None):
        if data is None:
            data = {}
        for v in data.values():
            if not isinstance(v, Qounter):
                raise TypeError("All values must be Qounter instances")
        super().__init__(data)

    def __getitem__(self, key):
        if key in self:
            return super().__getitem__(key)
        return Qounter()

    def __setitem__(self, key, value: Optional[Any]):
        if not isinstance(value, Qounter):
            if isinstance(value, int):
                value = Qounter({DUMMY_ITEM_TYPE: value})
            elif value:
                value = Qounter(value)
            else:
                value = Qounter(value)
        super().__setitem__(key, value)

    # def __repr__(self):
    #     # first_keys = list(self.data.keys())[:5]
    #     # mini_dict = {k: v for k, v in self.data.items() if v in first_keys}
    #     return f"MultiQounter({self})"

    def __add__(self, other: "MultiQounter"):
        """
        Addition for multicounters: for each object the multicounters share, the counters are summed.
        All objecs that are not shared are added as well.
        """
        new_data = MultiQounter()
        for obj in set(other.keys()).union(set(self.keys())):
            new_data[obj] = self[obj] + other[obj]
        return new_data

    def __sub__(self, other: "MultiQounter"):
        """
        Subtraction of multicounters: for each object the multicounters share, the other entry is subtracted.
        If the object is not shared, it is added as a negative counter.
        """
        new_data = MultiQounter()
        for obj in set(other.keys()).union(set(self.keys())):
            new_data[obj] = self[obj] - other[obj]
        return new_data

    def __radd__(self, other: "MultiQounter"):
        """
        Right addition for multicounters: if the other is a number, it is added to each counter.
        """
        if other == 0:
            return self
        return self.__add__(other)

    def __pos__(self):
        return MultiQounter({obj: +counter for obj, counter in self.items()})

    def __neg__(self):
        return MultiQounter({obj: -counter for obj, counter in self.items()})

    def __abs__(self):
        return MultiQounter({obj: abs(counter) for obj, counter in self.items()})

    def __bool__(self):
        """
        Returns True if at least one Counter in the MultiQounter is non-empty.
        """
        return any(bool(counter) for counter in self.values())

    @property
    def objects(self):
        """
        Returns a list of all objects that have a Counter assigned.
        """
        return list(self.keys())

    @property
    def item_types(self):
        """
        Returns a list of all item types that have a Counter assigned.
        """
        return list(set().union(*[x.item_types for x in self.values()]))

    @property
    def active_item_types(self):
        """
        Returns a list of all item types that have a non-zero count in any Counter.
        """
        return list(set().union(*[x.active_item_types for x in self.values()]))

    def positive_counterparts(self):
        """
        Returns a Multicounter containing only the positive counterparts of each counter.
        """
        return self.__pos__()

    def negative_counterparts(self):
        """
        Returns a Multicounter containing only the negative counterparts of each counter.
        """
        return self.__neg__()

    @property
    def counters(self):
        """
        Returns a list of all counters in the MultiQounter.
        """
        return list(self.values())

    @property
    def active_objects(self) -> List:
        """
        Returns a list of all quantity-active objects.
        """
        return [key for key, value in self.items() if bool(value)]
