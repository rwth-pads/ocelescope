# pm4py column names
PM4PY_ATTRIBUTE_CHANGE = "ocel:field"
PM4PY_OID = "ocel:oid"
PM4PY_OBJECT_TYPE = "ocel:type"
PM4PY_TIMESTAMP = "ocel:timestamp"
PM4PY_EID = "ocel:eid"
PM4PY_ACTIVITY = "ocel:activity"
PM4PY_E2O_QUALIFIER = "ocel:qualifier"
PM4PY_O2O_O1 = "ocel:oid"
PM4PY_O2O_O2 = "ocel:oid_2"
PM4PY_O2O_qualifier = "ocel:qualifier"
PM4PY_REQUIRED_E2O_COLS = [
    PM4PY_EID,
    PM4PY_ACTIVITY,
    PM4PY_TIMESTAMP,
    PM4PY_OID,
    PM4PY_OBJECT_TYPE,
    PM4PY_E2O_QUALIFIER,
]
PM4PY_COL_NAMES = [
    PM4PY_OID,
    PM4PY_OBJECT_TYPE,
    PM4PY_TIMESTAMP,
    PM4PY_EID,
    PM4PY_ACTIVITY,
    PM4PY_E2O_QUALIFIER,
    PM4PY_ATTRIBUTE_CHANGE,
    PM4PY_O2O_qualifier,
    PM4PY_O2O_O2,
    PM4PY_O2O_O1,
]
QEL_ITEM_TYPE = "qel:item_type"
QEL_QUANTITY = "qel:quantity"
QEL_QUANTITY_UPDATE = "qel:quantity_update"
QEL_ILVL = "qel:itlvl"

PM4PY_LOG_CASE = "case:concept:name"
PM4PY_LOG_ACTIVITY = "concept:name"
PM4PY_LOG_TIMESTAMP = "time:timestamp"

TERM_INPUT = "input"
TERM_OUTPUT = "output"
TERM_THROUGHPUT = "throughput"

TERM_INITIAL = "initial"
TERM_FINAL = "final"
TERM_INTERMEDIATE = "intermediate"

DUMMY_ITEM_TYPE = "it1"
DUMMY_INIT_EVENT = "init"
DUMMY_FINAL_EVENT = "final"
DUMMY_SOURCE = "source"  # probably no longer relevant
DUMMY_SINK = "sink"  # probably no longer relevant
DUMMY_INPUT = "input"
DUMMY_OUTPUT = "output"


CHART_COLOURS = [
    "#006165",  # petrol
    "#CE108A",  # pink
    "#0098A1",  # turquoise
    "#F6A800",  # orange
    "#00549F",  # blue
    "#6f2b4b",  # purple
    "#8EBAE5",  # light blue
    "#000080",  # dark blue
    "#007e56",  # lighter greeny-turquoise
    "#005d4c",  # perl-ophal green
    "#a1dfd7",  # light-turquoise
    "#cd00cd",  # pink
    "#28713e",  # green
    "#701f29",  # purpur-red
    "#5d2141",  # other purple
    "#a1dfd7",  # light-turquoise
    "#00ffff",  # cyan
    "#39ff14",  # neon green
    "#800080",  # purpur
    "#005f6a",  # blue-petrol
    "#76e1e0",  # another turquopise
    "#f5ff00",  # neon-yellow
]

XML_QUANTITY_EXTENSION = "quantity-extension"
XML_OPERATIONS = "operations"
XML_OPERATION = "operation"
XML_QUANTITIES = "quantities"
XML_QUANTITY = "quantity"
XML_EVENT_ID = "event-id"
XML_OBJECT_ID = "object-id"
XML_ITEM = "item"
XML_ITEM_TYPE = "type"
XML_QUANTITY_TYPE = "type"


def item_type_active_evaluation(value: int) -> bool:
    """
    Evaluates if the given value is item type active.
    """
    return value > 0
