from typing import Optional

from .BaseElement import ConnectedElement, ConnectingElement

class Place(ConnectedElement):
    def __init__(
        self,
        name,
        object_type: str,
        label: str = None,
        properties: dict = None,
        marking: Optional[int] = None,
        initial: Optional[bool] = None,
        final: Optional[bool] = None,
    ):
        super().__init__(name=name, label=label, properties=properties)

        self._initial = None
        self._final = None
        self._marking = None
        self.object_type = object_type

        if marking is not None:
            self.marking = marking

        if initial is not None:
            self.initial = initial

        if final is not None:
            self.final = final

    def __str__(self):
        return self.name

    @property
    def initial(self):
        if self._initial is not None:
            return self._initial
        else:
            pass

        if len(self.inputs) == 0:
            return True
        else:
            return False

    @initial.setter
    def initial(self, initial: bool):
        self._initial = initial

    @property
    def final(self):
        if self._final is not None:
            return self._final
        else:
            pass

        if len(self.outputs) == 0:
            return True
        else:
            return False

    @final.setter
    def final(self, final: bool):
        self._final = final

    @property
    def marking(self):
        return self._marking

    @marking.setter
    def marking(self, marking: int):
        if marking >= 0:
            self._marking = marking
        else:
            raise ValueError("Marking must be a non-negative integer.")

    def add_input(self, input_element: "Transition"):
        """
        Adds an input element to this connected element.
        """
        if isinstance(input_element, ConnectedElement) and not isinstance(input_element, Place):
            self.inputs.add(input_element)
        else:
            raise ValueError("Input must be a Transition object.")

    def add_output(self, output_element: "Transition"):
        """
        Adds an output element to this connected element.
        """
        if isinstance(output_element, ConnectedElement) and not isinstance(output_element, Place):
            self.outputs.add(output_element)
        else:
            raise ValueError("Output must be a Transition object.")

    # def get_input_arcs(self) -> set[]:
    #     """
    #     Returns a set of all input arcs connected to this element.
    #     """
    #     return {ConnectingElement(source=input_node, target=self, name=f"{input_node} -> {self.name}")
    #             for input_node in self.inputs}
    #
    # def get_output_arcs(self) -> set[ConnectingElement]:
    #     """
    #     Returns a set of all output arcs connected to this element.
    #     """
    #     return {ConnectingElement(source=self, target=output_node, name=f"{self.name} -> {output_node}")
    #             for output_node in self.outputs}


class DecouplingPoint(ConnectedElement):
    def __init__(
        self,
        name,
        object_type: str,
        label: str = None,
        properties: dict = None,
        marking: Optional[int] = None,
        dummy: Optional[bool] = False,
    ):
        super().__init__(name=name, label=label, properties=properties)

        self._marking = None
        self.object_type = object_type
        self.dummy = dummy   # indicates if this dp is a dummy dp

        if marking is not None:
            self.marking = marking

    def __str__(self):
        return self.name

    @property
    def marking(self):
        return self._marking

    @marking.setter
    def marking(self, marking: int):
        if marking >= 0:
            self._marking = marking
        else:
            raise ValueError("Marking must be a non-negative integer.")

    def add_input(self, input_element: "Transition"):
        """
        Adds an input element to this connected element.
        """
        if isinstance(input_element, ConnectedElement) and not isinstance(input_element, Place):
            self.inputs.add(input_element)
        else:
            raise ValueError("Input must be a Transition object.")

    def add_output(self, output_element: "Transition"):
        """
        Adds an output element to this connected element.
        """
        if isinstance(output_element, ConnectedElement) and not isinstance(output_element, Place):
            self.outputs.add(output_element)
        else:
            raise ValueError("Output must be a Transition object.")

class Transition(ConnectedElement):
    def __init__(
        self,
        name,
        label: str | None = None,
        properties: dict = None,
        handover: bool = False,
        duplicated: bool = False,
        variable_places: set[Place] = None,
        dummy: Optional[bool] = None,
        silent: Optional[bool] = None,
    ):
        super().__init__(name, label, properties)
        self._silent = False if label else None
        self._handover = handover
        self.dummy = False if dummy is None else dummy  # indicates if this transition is a dummy transition
        self._variable_places: set[Place] = set()  # all places connected with a variable arc
        self.variable_places = set() if variable_places is None else variable_places
        # self._duplicated = duplicated

        if silent:
            self.silent = silent

    def __repr__(self):
        return f"{self.name} ({self.label})"

    @property
    def handover(self) -> bool:
        return self._handover

    @handover.setter
    def handover(self, handover: bool):
        self._handover = handover

    @property
    def variable_places(self) -> set[Place]:
        """
        Returns a set of all places connected to this transition with a variable arc.
        """
        return self._variable_places

    @variable_places.setter
    def variable_places(self, variable_places: set[Place]):
        if variable_places.issubset(self.get_connected_nodes()):
            self._variable_places = variable_places
        else:
            raise ValueError(
                "Variable places must be a subset of the connected nodes (inputs and outputs) of this transition."
            )

    def get_variable_input_places(self) -> set[Place]:
        """
        Returns a set of all input places connected to this transition with a variable arc.
        """
        return self.variable_places.intersection(self.inputs)

    def get_variable_output_places(self) -> set[Place]:
        """
        Returns a set of all output places connected to this transition with a variable arc.
        """
        return self.variable_places.intersection(self.outputs)

    @property
    def input_handover(self) -> bool:
        """Returns True if this transition is a handover and if it has at least one input arc."""
        return self.handover and len(self.inputs)

    @property
    def output_handover(self) -> bool:
        """Returns True if this transition is a handover and if it has at least one output arc."""
        return self.handover and len(self.outputs)

    # @property
    # def duplicated(self) -> bool:
    #     return self._duplicated
    #
    # @duplicated.setter
    # def duplicated(self, duplicated: bool):
    #     self._duplicated = duplicated

    @property
    def silent(self):
        if self._silent is None:
            if self.label:
                return False
            else:
                return True
        else:
            return self._silent

    @silent.setter
    def silent(self, silent: bool):
        self._silent = silent

    @property
    def object_types(self) -> set[str]:
        surrounding_places = list(self.inputs | self.inputs)
        return {place.object_type for place in surrounding_places}

    def add_input(self, input_element: Place | DecouplingPoint):
        """
        Adds an input element to this connected element.
        """
        if isinstance(input_element, Place|DecouplingPoint):
            self.inputs.add(input_element)
        else:
            raise ValueError("Input must be a Place object.")

    def add_output(self, output_element: Place | DecouplingPoint):
        """
        Adds an output element to this connected element.
        """
        if isinstance(output_element, Place|DecouplingPoint):
            self.outputs.add(output_element)
        else:
            raise ValueError("Output must be a Place object.")


class Arc(ConnectingElement):
    def __init__(
        self,
        source,
        target,
        name=None,
        label: str = None,
        properties: dict = None,
        variable: bool = None,
    ):
        # source is place, target isn't
        c1 = isinstance(source, Place | DecouplingPoint) and not isinstance(target, Place | DecouplingPoint)
        # target is place, source isn't
        c2 = isinstance(target, Place | DecouplingPoint) and not isinstance(source, Place | DecouplingPoint)

        if c1 or c2:
            pass
        else:
            raise ValueError("Arcs may only connect a place to a transition or a transition to a place.")

        if name:
            pass
        else:
            name = f"({source.name}, {target.name})"
        super().__init__(source=source, target=target, name=name, label=label, properties=properties)
        self.variable = False if variable is None else variable

    @property
    def place(self):
        if isinstance(self.source, Place):
            return self.source
        else:
            return self.target

    @property
    def transition(self):
        if isinstance(self.source, Place):
            return self.target
        else:
            return self.source

    @property
    def object_type(self) -> str:
        """Returns the object type of the place connected to this arc."""
        return self.place.object_type  #

    # def get_output_of_node(self, node: ConnectedElement) -> set[ConnectedElement]:
    #     """Returns the output node of this arc given a source node."""
    #     if self.source == node:
    #         return self.target
    #     elif self.target == node:
    #         return self.source
    #     else:
    #         raise ValueError("The provided node is not connected to this arc.")
