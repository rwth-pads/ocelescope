import pandas as pd
from typing import Any, List, Optional, Dict, Tuple

from .GLOBAL import (
    PM4PY_TIMESTAMP,
    PM4PY_OID,
    PM4PY_OBJECT_TYPE,
    PM4PY_EID,
    PM4PY_ACTIVITY,
    QEL_ITEM_TYPE,
    QEL_QUANTITY,
    DUMMY_ITEM_TYPE,
    item_type_active_evaluation,
    DUMMY_INIT_EVENT,
    DUMMY_FINAL_EVENT,
    DUMMY_SOURCE,
    DUMMY_SINK,
    QEL_QUANTITY_UPDATE,
    QEL_ILVL,
    PM4PY_LOG_CASE,
)
from .Qounter import Qounter, MultiQounter, Counter
from .GLOBAL import PM4PY_LOG_ACTIVITY
from pm4py.objects.log.obj import Event, EventLog
from pm4py.objects.log.obj import Trace as PM4PYTrace


class QuantityEvent(MultiQounter):
    def __init__(
        self,
        event_id: Any,
        activity: Any,
        timestamp: Optional[Any] = None,
        event_qops: Optional[Any] = None,
        initial_dummy: Optional[bool] = False,
        final_dummy: Optional[bool] = False,
    ) -> None:
        self.event_id = event_id
        self.activity = activity
        self.timestamp: Any = timestamp
        self.initial_dummy: bool = initial_dummy
        self.final_dummy: bool = final_dummy
        super().__init__(event_qops)

    def __str__(self):
        return f"{self.event_id} ({self.activity}): {super().__str__()}"

    def __name__(self):
        return f"{self.event_id} ({self.activity}): {super().__name__()}"

    def __repr__(self):
        return f"{self.event_id} ({self.activity}): {super().__repr__()}"

    @property
    def delta(self):
        """
        Returns the sum of all quantity operations as Counter.
        """
        if not self.counters:
            return Counter()
        return sum(self.counters)

    def get_inputs(self) -> Qounter:
        """
        Aggregation/Composition of all negative counter parts of the quantity operations.
        """
        return sum(self.negative_counterparts().counters)

    def get_outputs(self) -> Qounter:
        """
        Aggregation/Composition of all positive counter parts of the quantity operations.
        """
        return sum(self.positive_counterparts().counters)

    def handover(self) -> bool:
        """
        Returns the handover of the event, which is the difference between outputs and inputs.
        """
        if self.get_outputs():
            return True
        elif self.get_inputs():
            return True
        else:
            return False

    def creation(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> bool:
        """
        Returns True if the event is a creation event, i.e., it has a positive delta.
        """
        return self.delta[item_type] > 0

    def consumption(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> bool:
        """
        Returns True if the event is a creation event, i.e., it has a positive delta.
        """
        return self.delta[item_type] < 0


class TraceEntry:
    def __init__(
        self,
        event: QuantityEvent,
        qop: Optional[Qounter | int] = None,
        ilvl: Optional[Qounter] = None,
    ):
        self.event: QuantityEvent = event

        if isinstance(qop, int):
            qop = Qounter({DUMMY_ITEM_TYPE: qop})

        self.qop: Qounter = qop if qop is not None else Qounter()
        self.ilvl: Qounter = ilvl if ilvl is not None else Qounter()

    def __repr__(self):
        return f"{self.event.event_id} (qop: {self.qop})"

    def __str__(self):
        return f"{self.event.event_id} (qop: {self.qop})"

    def __name__(self):
        return f"{self.event.event_id} (qop: {self.qop})"

    def item_type_involved(self, item_type: Any) -> bool:
        """
        Returns True if the item type level is positive, yet unchanged for the given item type.
        """
        return (self.ilvl[item_type] - self.qop[item_type]) == self.ilvl[item_type] > 0

    def item_type_active(self, item_type: Any = DUMMY_ITEM_TYPE) -> bool:
        """
        Return true if the item type level is positive before or after the quantity update.
        """
        return (item_type_active_evaluation(self.ilvl[item_type] - self.qop[item_type])) | (
            item_type_active_evaluation(self.ilvl[item_type])
        )

    def item_type_adding(self, item_type: Any = DUMMY_ITEM_TYPE) -> bool:
        """
        Returns True if the quantity operation is adding items for the given item type.
        """
        return (self.qop[item_type] > 0) and (self.ilvl[item_type] > 0)

    def item_type_removing(self, item_type: Any = DUMMY_ITEM_TYPE) -> bool:
        """
        Returns True if the quantity operation is removing items for the given item type.
        """
        return (self.qop[item_type] < 0) and (self.ilvl[item_type] >= 0)


class Trace(list):
    """
    The Trace class is used to represent a trace of events in Qbject.
    It contains a list of TraceEntry objects.
    """

    def __init__(self, *args):
        super().__init__(*args)

    @property
    def events(self) -> List[QuantityEvent]:
        """
        Returns a list of all QuantityEvents in the trace.
        """
        return [entry.event for entry in self]

    @property
    def quantity_operations(self) -> List[Qounter]:
        """
        Returns a list of all Qounters in the trace.
        """
        return [entry.qop for entry in self]

    @property
    def item_levels(self) -> List[Qounter]:
        """
        Returns a list of all initial item levels in the trace.
        """
        return [entry.ilvl for entry in self]

    #
    # def get_first_ilvl(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> int:
    #     """
    #     Returns the initial item level for the given item type from the first trace entry.
    #     If the item type is not present, it returns 0.
    #     """
    #     if self and item_type in self[0].ilvl:
    #         return self[0].ilvl[item_type]
    #     return 0
    #
    # def get_first_qop(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> int:
    #     """
    #     Returns the initial quantity operation for the given item type from the first trace entry.
    #     If the item type is not present, it returns 0.
    #     """
    #     if self and item_type in self[0].qop:
    #         return self[0].qop[item_type]
    #     return 0
    #
    def get_last_ilvl(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> int:
        """
        Returns the initial item level for the given item type from the last trace entry.
        If the item type is not present, it returns 0.
        """
        if self and item_type in self[-1].ilvl:
            return self[-1].ilvl[item_type]
        return 0

    #
    # def get_last_qop(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> int:
    #     """
    #     Returns the initial quantity operation for the given item type from the last trace entry.
    #     If the item type is not present, it returns 0.
    #     """
    #     if self and item_type in self[-1].qop:
    #         return self[-1].qop[item_type]
    #     return 0

    def active_item_types(self) -> List[Any]:
        """
        Returns a list of all item types that have a non-zero count in the trace.
        """
        return list(set(entry.qop.active_item_types for entry in self))

    def quantity_updates(self, item_type: Any) -> List[Qounter]:
        """
        Returns a list of all Qounters for a specific item type in the trace.
        """
        return [entry.qop[item_type] for entry in self if item_type in entry.qop]

    def item_type_levels(self, item_type: Any) -> List[Qounter]:
        """
        Returns a list of all initial item levels for a specific item type in the trace.
        """
        return [entry.ilvl[item_type] for entry in self if item_type in entry.ilvl]

    def determine_item_levels(self):
        """
        Determines the item levels for all events.
        For every trace entry, it determined the sum of the quantity operations for all previous trace entries.
        """
        item_levels = Qounter()
        for entry in self:
            item_levels = item_levels + entry.qop
            entry.ilvl = item_levels.copy()

    def add_initial_entry(self, new_init: TraceEntry):
        """
        Adds new first trace entry.
        """
        self.insert(0, new_init)

    def add_final_entry(self, new_final: TraceEntry):
        """
        Adds new final trace entry.
        """
        new_final.ilvl = self.item_levels[-1] + new_final.qop
        self.insert(len(self), new_final)

    def get_item_type_involved_list(self, item_type: Any) -> List[bool]:
        """
        Returns a list of booleans indicating if the item type is involved in each trace entry.
        """
        return [entry.item_type_involved(item_type) for entry in self]

    def get_event_strings(self):
        """
        Returns a list of strings representing the events in the trace.
        """
        return [entry.event.event_id for entry in self]

    def get_activity_strings(self):
        """
        Returns a list of strings representing the activities in the trace.
        """
        return [entry.event.activity for entry in self]

    def drop_initial_entry(self):
        """
        Drops the first trace entry.
        """
        if self:
            self.pop(0)

    def drop_final_entry(self):
        """
        Drops the last trace entry.
        """
        if self:
            self.pop(-1)

    def initial_dummy(self) -> bool:
        """
        Returns True if the first trace entry is a dummy initial entry.
        """
        return self[0].event.initial_dummy

    def final_dummy(self) -> bool:
        """
        Returns True if the last trace entry is a dummy final entry.
        """
        return self[-1].event.final_dummy

    def get_first_activity(self) -> str:
        """
        Returns the first activity in the trace.
        """
        if self:
            return self[0].event.activity
        return ""

    def info_item_type_involved_sequence(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> List[bool]:
        """
        Returns a list informing which entries are item type involved in the trace.
        """
        return [entry.item_type_involved(item_type) for entry in self]

    def get_item_type_active_activities(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> List[str]:
        """
        Returns a list of activities to which the trace has item type active entries.
        """
        return list(set([entry.event.activity for entry in self if entry.item_type_active(item_type)]))

    def get_item_type_adding_activities(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> List[str]:
        """
        Returns a list of events to which the trace has item type adding entries.
        """
        return list(set([f"{entry.event.activity} (handover)" for entry in self if entry.item_type_adding(item_type)]))

    def get_item_type_removing_activities(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> List[str]:
        """
        Returns a list of events to which the trace has item type adding entries.
        """
        return list(
            set([f"{entry.event.activity} (handover)" for entry in self if entry.item_type_removing(item_type)])
        )


class QuantityObject:
    """
    The QuantityObjects class is used as base class for the discovery of Qnets.
    """

    def __init__(
        self,
        object_type: Any,
        object_id: Any,
        init_ilvl: Optional[int | Qounter] = None,
        source: bool = False,
        sink: bool = False,
    ):
        self.object_type: Any = object_type
        self.object_id: Any = object_id
        if isinstance(init_ilvl, int):
            init_ilvl = Qounter({DUMMY_ITEM_TYPE: init_ilvl})
        self.init_ilvl = init_ilvl if init_ilvl is not None else Qounter()
        self._trace: Trace = Trace()
        self.item_movements: List[Trace] = []
        self.decoupling_point: bool = False
        self.item_flow_sequences = []
        # self.source: bool = source
        # self.sink: bool = sink

    def __repr__(self):
        return f"{self.object_id} ({self.object_type}): {self._trace}"

    def __str__(self):
        return f"{self.object_id} ({self.object_type}): {self._trace}"

    def __name__(self):
        return f"{self.object_id} ({self.object_type}): {self._trace}"

    def reset_decoupling_pint(self):
        self.decoupling_point = False

    def carrier(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> bool:
        """
        Returns True if the object is a carrier.
        """
        if self.get_item_type_active_activities(item_type=item_type):
            if self.decoupling_point:
                return False
            else:
                return True
        else:
            return False

    @property
    def trace(self) -> Trace:
        """
        Returns the trace of the object.
        """
        return self._trace

    @trace.setter
    def trace(self, value: Trace):
        """
        Sets the trace of the object.
        """
        self._trace = value

    def add_trace(self, trace: Trace):
        """
        Adds a trace to the object.
        """
        self._trace.extend(trace)

    def get_initial_itlvl(self, item_type: Any = DUMMY_ITEM_TYPE) -> int:
        """
        Returns the initial item level for the given item type.
        If the item type is not present, it returns 0.
        """
        return self.init_ilvl[item_type]

    def get_final_ilvl(self) -> Qounter:
        if self._trace.final_dummy():
            return self._trace.item_levels[-2]
        else:
            return self._trace.item_levels[-1]

    def get_final_itlvl(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> int:
        if self._trace.final_dummy():
            return self._trace.item_levels[-2][item_type]
        else:
            return self._trace.item_levels[-1][item_type]

    def initial_it_active(self, item_type: Any = DUMMY_ITEM_TYPE) -> int:
        """
        Returns the initial item level for the given item type.
        If the item type is not present, it returns 0.
        """
        return item_type_active_evaluation(self.init_ilvl[item_type])

    def final_it_active(self, item_type: Any = DUMMY_ITEM_TYPE) -> int:
        """
        Returns True if the final item level for the given item type is active.
        If the item type is not present, it returns False.
        """
        return item_type_active_evaluation(self.get_final_itlvl(item_type))

    def add_initial_event(self, qevent: QuantityEvent):
        """
        Adds an initial event to the trace with the initial item level if required.
        """
        # drop initial entry if it is a dummy initial entry
        if self._trace.initial_dummy():
            self._trace.drop_initial_entry()

        initial_entry = TraceEntry(event=qevent, qop=qevent[self.object_id])
        self._trace.add_initial_entry(initial_entry)

    def determine_item_levels(self):
        """
        Determines the item levels for the trace.
        For every trace entry, it determined the sum of the quantity operations for all previous trace entries.
        """
        self._trace.determine_item_levels()

    def add_final_event(self, qevent: QuantityEvent):
        """
        Adds a final event to the trace with the final item level if required.
        """
        # drop final entry if it is a dummy final entry
        if self._trace.final_dummy():
            self._trace.drop_final_entry()

        final_entry = TraceEntry(event=qevent, qop=qevent[self.object_id])
        self._trace.add_final_entry(final_entry)

    def get_first_activity(self) -> str:
        """
        Returns the first activity in the trace.
        """
        if self._trace.initial_dummy():
            return self._trace[1].event.activity
        else:
            return self._trace[0].event.activity

    def get_final_activity(self) -> str:
        """
        Returns the final activity in the trace.
        """
        if self._trace.final_dummy():
            return self._trace[-2].event.activity
        else:
            return self._trace[-1].event.activity

    def info_item_type_involved_sequence(self):
        """
        Returns a list informing how which entries are item type involved in the trace.
        """
        return self._trace.info_item_type_involved_sequence()

    def project_trace_to_item_type_involved(self, item_type: Any):
        """
        Projects the trace to the item type active sequence.
        This means that only the item type active entries are kept in the trace.
        """
        # TODO: this will have to be changed to returning item movements
        self._trace = Trace([entry for entry in self._trace if entry.item_type_involved(item_type)])

    def get_events(self) -> List[QuantityEvent]:
        """
        Returns a list of all QuantityEvents in the trace.
        """
        return self._trace.events

    def get_item_type_active_activities(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> List[str]:
        """
        Returns a list of activities with an active handover for the given item type.
        A handover is active if the event has a non-zero quantity update for the given item type.
        """
        return self._trace.get_item_type_active_activities(item_type=item_type)

    def get_item_level_data(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> pd.DataFrame:
        """
        Returns a dataframe with the event_id, activity, and item type level for all entries in the trace.
        """
        self.determine_item_levels()
        data = {
            PM4PY_EID: [entry.event.event_id for entry in self._trace],
            PM4PY_ACTIVITY: [entry.event.activity for entry in self._trace],
            QEL_QUANTITY: [entry.ilvl[item_type] for entry in self._trace],
        }
        return pd.DataFrame(data)

    def get_e2o_dataframe(self, item_type: Optional[Any]) -> pd.DataFrame:
        """
        Returns a dataframe with the event_id, object_id, and item type level for all entries in the trace.
        """
        self.determine_item_levels()
        data = {
            PM4PY_EID: self._trace.get_event_strings(),
            PM4PY_ACTIVITY: self._trace.get_activity_strings(),
            PM4PY_TIMESTAMP: [entry.event.timestamp for entry in self._trace],
            PM4PY_OID: [self.object_id] * len(self._trace),
            PM4PY_OBJECT_TYPE: [self.object_type] * len(self._trace),
            QEL_ITEM_TYPE: [item_type] * len(self._trace) if item_type is not None else [],
            QEL_ILVL: [entry.ilvl[item_type] for entry in self._trace] if item_type is not None else [],
            QEL_QUANTITY_UPDATE: [entry.qop[item_type] for entry in self._trace] if item_type is not None else [],
        }
        df = pd.DataFrame(data)

        # if df[PM4PY_TIMESTAMP].empty:
        #     df[PM4PY_TIMESTAMP] = [f"{i}-{self.object_id}" for i in np.arange(0, len(df))]  # Ensure timestamp column is present even if empty

        return df

    def determine_item_movements(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE):
        """
        Splits the object trace (if required) into the individual item movements for the given item type.
        """
        item_movements = []
        current_movement = Trace()
        last_movement_removing = False
        for entry in self._trace:
            if entry.item_type_adding(item_type=item_type):
                if last_movement_removing:
                    self.decoupling_point = True
                    self.item_movements = []
                    break
                else:
                    current_movement.append(entry)
                    last_movement_removing = False
            elif entry.item_type_removing(item_type=item_type):
                current_movement.append(entry)
                last_movement_removing = True
                if entry.ilvl[item_type] <= 0:
                    item_movements.append(current_movement.copy())
                    current_movement = Trace()
                    last_movement_removing = False
            elif entry.item_type_involved(item_type=item_type):
                current_movement.append(entry)
            else:
                if current_movement:
                    print(self.object_id)
                    print(current_movement)
                    raise ValueError("Bug! not item type active but there is a running movement")
                else:
                    pass

        self.item_movements = item_movements

    def create_activity_sequences(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE):
        pm4py_traces = []
        for num, item_movement in enumerate(self.item_movements):
            adding_entries = [entry for entry in item_movement if entry.item_type_adding(item_type=item_type)]
            removing_entries = [entry for entry in item_movement if entry.item_type_removing(item_type=item_type)]

            for adding_entry in adding_entries:
                current_removing_entries = removing_entries.copy()
                current_subtrace = PM4PYTrace()
                for entry in item_movement:
                    if entry == adding_entry:
                        pm4py_event = Event()
                        pm4py_event[PM4PY_LOG_ACTIVITY] = f"{entry.event.activity} (handover)"
                        pm4py_event["event_name"] = f"{self.object_id}-{len(pm4py_traces)}-{entry.event.event_id}"
                        current_subtrace.append(pm4py_event)
                    else:
                        if current_subtrace:
                            # check if it is the next removing activity
                            if entry in current_removing_entries:
                                # remove from list of removing entries
                                current_removing_entries.remove(entry)

                                # create the handover event
                                pm4py_event = Event()
                                pm4py_event[PM4PY_LOG_ACTIVITY] = f"{entry.event.activity} (handover)"
                                pm4py_event["event_name"] = (
                                    f"{self.object_id}-{len(pm4py_traces)}-{entry.event.event_id}"
                                )

                                # check if there is another removing entry after this one => if yes, duplicate the current trace
                                if current_removing_entries:
                                    # add this item flow to list of traces but copy it first
                                    current_subtrace_handover = PM4PYTrace(current_subtrace)
                                    current_subtrace_handover.append(pm4py_event)
                                    pm4py_traces.append(current_subtrace_handover)
                                    # print(pm4py_traces)

                                    # extend the current subtrace with the event but not as handover.
                                    pm4py_event_duplicate = Event()
                                    pm4py_event_duplicate[PM4PY_LOG_ACTIVITY] = f"{entry.event.activity}"
                                    pm4py_event_duplicate["event_name"] = (
                                        f"{self.object_id}-{len(pm4py_traces)}-{entry.event.event_id}"
                                    )
                                    current_subtrace.append(pm4py_event_duplicate)
                                    # print(pm4py_traces)
                                else:  # if not, just add the handover event to the current trace
                                    current_subtrace.append(pm4py_event)
                                    pm4py_traces.append(current_subtrace)
                                    break

                            # if not, just append it until we reach the next removing entry
                            else:
                                pm4py_event = Event()
                                pm4py_event[PM4PY_LOG_ACTIVITY] = entry.event.activity
                                pm4py_event["event_name"] = (
                                    f"{self.object_id}-{len(pm4py_traces)}-{entry.event.event_id}"
                                )
                                current_subtrace.append(pm4py_event)
                        # if the current subtrace is still empty, the item flow hasn't started yet, so we ignore it.
                        else:
                            pass
        self.item_flow_sequences = pm4py_traces

    def get_item_type_adding_activities(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> List[QuantityEvent]:
        """
        Returns a list of events to which the trace has item type adding entries.
        """
        return self._trace.get_item_type_adding_activities(item_type=item_type)

    def get_item_type_removing_activities(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> List[QuantityEvent]:
        """
        Returns a list of events to which the trace has item type adding entries.
        """
        return self._trace.get_item_type_removing_activities(item_type=item_type)


class DisqoveryQEL:
    """
    The DisqoveryQEL class is used as base class for the discovery of Qnets.
    """

    def __init__(
        self,
        qbjects: Optional[List[QuantityObject]] = None,
        true_events: Optional[List[QuantityEvent]] = None,
    ):
        self.objects = [] if qbjects is None else qbjects
        self.events = true_events if true_events is not None else []

    def __repr__(self):
        return f"Quantity Event Log with {len(self.events)} events and the following objects: {self.objects}."

    @property
    def dummy_events(self) -> List[QuantityEvent]:
        """
        Returns a list of all dummy events in the event log.
        """
        return [event for event in self.events if event.initial_dummy or event.final_dummy]

    def get_object_types(self):
        """
        Returns a list of all object types in the event log.
        """
        return list(set(obj.object_type for obj in self.objects))

    def get_objects_by_type(self, object_type: Any) -> List[QuantityObject]:
        """
        Returns a list of all QuantityObjects of the given object type in the event log.
        """
        return [obj for obj in self.objects if obj.object_type == object_type]

    def add_true_events(self, events: List[QuantityEvent]):
        """
        Adds real events to the event log.
        """
        self.events.extend(events)

    def add_dummy_event(self, dummy_event: QuantityEvent):
        """
        Adds a dummy event to the event log.
        """
        self.events.append(dummy_event)

    def add_initial_and_final_events(self):
        """
        Adds initial and final events to the event log for objects ensureing that every object:
         - starts with an item type level of zero on the passed item type, and
         - ends with an item type level of zero in the passed item type.
        The initial event is added if the initial item level is it-active => the object starts with items on it.
        The final event is added if the final item level is it-active => the object ends with items on it.
        """

        for obj in self.objects:
            # add initial event if initial item level is not it-active on the given item type
            initial_event = QuantityEvent(
                event_id=f"{DUMMY_INIT_EVENT}-{obj.object_type}-{obj.get_first_activity()}-{len(self.events)}",
                activity=f"{DUMMY_INIT_EVENT}-{obj.object_type}-{obj.get_first_activity()}",
                initial_dummy=True,
            )
            initial_event[obj.object_id] = obj.init_ilvl
            obj.add_initial_event(initial_event)
            self.add_dummy_event(dummy_event=initial_event)

            # determine item levels for the trace
            obj.determine_item_levels()

            # add final event if final item level is not it-active on the given item type
            final_event = QuantityEvent(
                event_id=f"{DUMMY_FINAL_EVENT}-{obj.object_type}-{obj.get_final_activity()}-{len(self.events)}",
                activity=f"{DUMMY_FINAL_EVENT}-{obj.object_type}-{obj.get_final_activity()}",
                final_dummy=True,
            )
            final_event[obj.object_id] = Qounter() - obj.get_final_ilvl()
            obj.add_final_event(final_event)
            self.add_dummy_event(dummy_event=final_event)

        #     if include_projection:
        #         # remove it-inactive events
        #         obj.project_trace_to_item_type_involved(item_type=item_type)
        #         if len(obj.trace) > 0:
        #             it_involved_objects_list.append(obj)
        #             new_event_list.extend(obj.get_events())
        #
        # if include_projection:
        #     # update event list so it only contains events that are it-active
        #     unique_event_ids = set([event.event_id for event in new_event_list])
        #     unique_events = [event for event in self.events if event.event_id in unique_event_ids]
        #     self.events = unique_events
        #     self.objects = it_involved_objects_list

    # def project_traces_to_item_type_involved(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE):
    #     """
    #     Projects the traces to the item type active sequence.
    #     This means that only the item type involved entries are kept in the trace.
    #     """
    #     new_event_list = []
    #     object_list = []
    #     for obj in self.objects:
    #         obj.project_trace_to_item_type_involved(item_type=item_type)
    #         if len(obj.trace) > 0:
    #             object_list.append(obj)
    #             # add events of the object to the new event list
    #             new_event_list.extend(obj.get_events())
    #
    #     # update event list so it only contains events that are it-active
    #     unique_event_ids = set([event.event_id for event in self.events])
    #     unique_events = [event for event in self.events if event.event_id in unique_event_ids]
    #     self.events = unique_events
    #     self.objects = object_list

    def prepare_traces_for_item_type_discovery(
        self,
        item_type: Optional[Any] = DUMMY_ITEM_TYPE,
    ):
        """
        Create all necessary starts and ends for the item traces.
        """
        self.add_initial_and_final_events()
        self.determine_item_movements(item_type=item_type)
        self.determine_item_flows(item_type=item_type)
        # self.add_sources_and_sinks(item_type=item_type)

    # def add_sources_and_sinks(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE):
    #     """
    #     Adds dummy source and sink objects to the event log.
    #     """
    #     # empty dummy objects
    #     self.dummy_objects = []
    #
    #     # identify all events with creations and consumptions (including dummies)
    #     for event in self.events:
    #
    #         count = event.delta[item_type]
    #
    #         # if creation of item(s), aka more items are passed on than removed:
    #         if count > 0:
    #             # create removal of item(s) from the source object
    #             additional_removal = Qounter({item_type: 0-count})
    #
    #             # create & add source object with initial item level corresponding to the number of items "removed from it" aka created
    #             source = QuantityObject(object_type=f"{DUMMY_SOURCE}-{item_type}", object_id=f"{DUMMY_SOURCE}-{len(self.objects)}", init_ilvl=Qounter({item_type: count}), source=True)
    #             trace_entry = TraceEntry(event=event, qop=additional_removal, ilvl=Qounter({item_type: 0}))
    #             source.add_trace(Trace([trace_entry]))
    #
    #             # add to dummy objects
    #             self.dummy_objects.append(source)
    #
    #             # add removal operation to event
    #             event[source.object_id] = additional_removal
    #
    #         # if consumption on item(s), aka more items are removed than passed on:
    #         elif count < 0:
    #             addition_to_sink = Qounter({item_type: 0-count})
    #
    #             # add sink object with negative item level to which the items are added, aka consumed
    #             sink = QuantityObject(object_type=f"{DUMMY_SINK}-{item_type}", object_id=f"{DUMMY_SINK}-{len(self.objects)}", init_ilvl=Qounter({item_type: count}), sink=True)
    #             trace_entry = TraceEntry(event=event, qop=addition_to_sink, ilvl=Qounter({item_type: 0}))
    #             sink.add_trace(Trace([trace_entry]))
    #
    #             # add to dummy objects
    #             self.dummy_objects.append(sink)
    #
    #             # add quantity operation to event
    #             event[sink.object_id] = addition_to_sink
    #
    #         else:
    #             pass

    def get_object_with_id(self, object_id: Any) -> Optional[QuantityObject]:
        """
        Returns the QuantityObjects with the given object_id.
        """
        for obj in self.objects:
            if obj.object_id == object_id:
                return obj
        return None

    def get_event_with_id(self, event_id: Any) -> Optional[QuantityEvent]:
        """
        Returns the QuantityEvent with the given event_id.
        """
        for event in self.events:
            if event.event_id == event_id:
                return event
        return None

    def get_pm4py_log_for_object_type(self, object_type: Any) -> EventLog:
        """
        Returns a PM4PY EventLog for the given object type.
        The log contains traces with events that have the given object type.
        """
        log = EventLog()
        for obj in self.get_objects_by_type(object_type):
            for num, item_flow in enumerate(obj.item_flow_sequences):
                trace_name = f"{obj.object_type}-{obj.object_id}-{num}"
                item_flow.attributes[PM4PY_LOG_CASE] = trace_name
                log.append(item_flow)

        return log

    #
    # def get_handover_activities(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> List[str]:
    #     """
    #     Returns a list of activities that are handover activities, i.e., activities where the event has a handover.
    #     """
    #     return list(set([event.activity for event in self.events if event.handover(item_type)]))

    def get_creation_activities(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> List[str]:
        """
        Returns a list of activities that are creation activities, i.e., activities where the event has a positive delta.
        """
        return list(set([f"{event.activity} (handover)" for event in self.events if event.creation(item_type)]))

    def get_consumption_activities(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> List[str]:
        """
        Returns a list of activities that are consumption activities, i.e., activities where the event has a negative delta.
        """
        return list(set([f"{event.activity} (handover)" for event in self.events if event.consumption(item_type)]))

    def get_activities_of_multiple_object_types(self) -> List[str]:
        """
        Returns a list of activities that are performed by multiple object types.
        Iterates through all objects and collects the activities.
        """
        activity_dict: Dict[str, set[str]] = dict()
        for obj in self.objects:
            for event in obj.get_events():
                if event.activity not in activity_dict.keys():
                    activity_dict[event.activity] = {obj.object_type}
                else:
                    activity_dict[event.activity].add(obj.object_type)

        return [activity for activity, types in activity_dict.items() if len(types) > 1]

    # def get_activities_multiple_object_types_no_handovers(self) -> List[str]:
    #     """
    #     Returns a list of activities that are performed by multiple object types, excluding handover activities.
    #     Iterates through all objects and collects the activities.
    #     """
    #
    #     return [
    #         activity
    #         for activity in self.get_activities_of_multiple_object_types()
    #         if activity not in self.get_handover_activities()
    #     ]

    def get_item_type_active_types(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE) -> Dict[str, set[str]]:
        """
        Returns a list of tuples with the object type and activity of active handovers for the given item type.
        """
        all_object_types = self.get_object_types()
        handovers = dict(zip(all_object_types, [set()] * len(all_object_types)))
        for object_type in all_object_types:
            for obj in self.get_objects_by_type(object_type):
                handovers[object_type] = handovers[object_type].union(
                    {f"{name} (handover)" for name in obj.get_item_type_active_activities(item_type=item_type)}
                )

        return handovers

    def get_item_type_level_dev_for_object(
        self, object_id: Any, item_type: Optional[Any] = DUMMY_ITEM_TYPE
    ) -> pd.DataFrame:
        """
        Returns a DataFrame with the event_id, activity, and item type level for the given object_id.
        If the object_id is not found, it returns an empty DataFrame.
        """
        obj = self.get_object_with_id(object_id)
        if obj:
            return obj.get_item_level_data(item_type=item_type)
        else:
            return pd.DataFrame(columns=[PM4PY_EID, PM4PY_ACTIVITY, QEL_QUANTITY])

    def get_e2o_dataframe(self, item_type: Optional[str] = DUMMY_ITEM_TYPE) -> pd.DataFrame:
        """
        Returns a DataFrame with the event_id, object_id, activity, and item type level for all events in the event log.
        """
        e2o_df = pd.DataFrame()
        for obj in self.objects:
            obj_df = obj.get_e2o_dataframe(item_type=item_type)
            e2o_df = pd.concat([e2o_df, obj_df], ignore_index=True)
        return e2o_df

    def get_object_ids(self) -> List[Any]:
        """
        Returns a list of all object IDs in the event log.
        """
        return [obj.object_id for obj in self.objects]

    def determine_item_movements(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE):
        """
        Determines the item movements for all objects in the event log.
        """
        for obj in self.objects:
            # print(obj.object_id)
            obj.determine_item_movements(item_type=item_type)

    def determine_item_flows(self, item_type: Optional[Any] = DUMMY_ITEM_TYPE):
        """
        Determines the item flows for all objects in the event log.
        """
        for obj in self.objects:
            if obj.carrier(item_type=item_type):
                obj.create_activity_sequences(item_type=item_type)
            else:
                pass

    def get_decoupling_points(self) -> List[QuantityObject]:
        """
        Returns a list of object IDs that are decoupling points.
        """
        return [obj for obj in self.objects if obj.decoupling_point]


def create_pm4py_log_from_log_dict(log_dict: Dict[str, List[QuantityEvent]]):
    """
    Create a PM4PY EventLog from a dictionary where keys are object IDs and values are lists of QuantityEvents.
    """
    log = EventLog()
    for trace_name, events in log_dict.items():
        trace = PM4PYTrace()
        trace.attributes[PM4PY_LOG_CASE] = trace_name
        for event in events:
            pm4py_event = Event()
            pm4py_event[PM4PY_LOG_ACTIVITY] = event.activity
            pm4py_event["event_name"] = event.event_id
            trace.append(pm4py_event)
        log.append(trace)
    return log
