from typing import List, Tuple, Dict, Optional

from pm4py.objects.petri_net.obj import PetriNet, Marking
import pm4py

from .GLOBAL import (
    DUMMY_INIT_EVENT,
    DUMMY_FINAL_EVENT,
    DUMMY_INPUT,
    DUMMY_OUTPUT,
    DUMMY_ITEM_TYPE,
    PM4PY_EID,
    PM4PY_ACTIVITY,
    PM4PY_TIMESTAMP,
    PM4PY_OID,
    PM4PY_OBJECT_TYPE,
)
from .NetElements import Transition, Place, DecouplingPoint
from .Qounter import Qounter
from .QuantityNet import QuantityNet
from .disqovery import DisqoveryQEL, QuantityEvent, QuantityObject, Trace, TraceEntry


def create_disqovery_qel_from_tuples(
    object_list: List[Tuple[str, str, List[Tuple[str, int | Qounter]]]],
    event_info: List[Tuple[str, str]],
) -> DisqoveryQEL:
    """
    Create a DisqoveryQEL from the given object list and event information.

    :param object_list: List of objects with their ID, type, and tuple events.
    :param event_info: List of events with their ID and type.
    :return: DisqoveryQEL instance.
    """

    # create events
    event_elements = dict()
    for event in event_info:
        event_elements[event[0]] = QuantityEvent(event[0], event[1])

    qbjects = []
    for obj in object_list:
        qo = QuantityObject(object_id=obj[0], object_type=obj[1], init_ilvl=obj[3])
        trace = Trace()
        for ev in obj[2]:
            # update quantity operations for event
            ev_element = event_elements[ev[0]]
            ev_element[obj[0]] = ev[1]
            # create trace entry
            trace_entry = TraceEntry(event=ev_element, qop=ev[1])
            trace.append(trace_entry)

        # add trace to quantity object
        qo.add_trace(trace)

        # add quantity object to list
        qbjects.append(qo)

    return DisqoveryQEL(qbjects, list(event_elements.values()))


# def create_disqovery_qel_from_with_time(object_list: List[Tuple[str, str, List[Tuple[str, int | Qounter]]]],
#                                      event_info: List[Tuple[str, str, int|datetime.datetime]]) -> DisqoveryQEL:
#     """
#     Create a DisqoveryQEL from the given object list and event information.
#
#     :param object_list: List of objects with their ID, type, and tuple events.
#     :param event_info: List of events with their ID and type.
#     :return: DisqoveryQEL instance.
#     """
#
#     # create events
#     event_elements = dict()
#     for event in event_info:
#         event_elements[event[0]] = QuantityEvent(event[0], event[1])
#
#     qbjects = []
#     for obj in object_list:
#         qo = QuantityObject(object_id=obj[0], object_type=obj[1], init_ilvl = obj[3])
#         trace = Trace()
#         for ev in obj[2]:
#             # update quantity operations for event
#             ev_element = event_elements[ev[0]]
#             ev_element[obj[0]] = ev[1]
#             # create trace entry
#             trace_entry = TraceEntry(event=ev_element, qop=ev[1])
#             trace.append(trace_entry)
#
#         # add trace to quantity object
#         qo.add_trace(trace)
#
#         # add quantity object to list
#         qbjects.append(qo)
#
#     return DisqoveryQEL(qbjects, list(event_elements.values()))


def discover_subnets(
    qel: DisqoveryQEL, show_nets: bool = False, export_subnets: bool = False
) -> Dict[str, Tuple[PetriNet, Marking, Marking]]:
    """
    Discover subnets for each object type in the given DisqoveryQEL.

    :param qel: DisqoveryQEL instance.
    :return: Dictionary of subnets for each object type.
    """
    pm4py_subnets = {}
    for ot in qel.get_object_types():
        pm4py_log = qel.get_pm4py_log_for_object_type(ot)
        net, im, fm = pm4py.discover_petri_net_inductive(pm4py_log)
        pm4py_subnets[ot] = (net, im, fm)
        if show_nets:
            print(ot)
            pm4py.view_petri_net(net, im, fm)
        if export_subnets:
            pm4py.save_vis_petri_net(net, im, fm, f"subnet-{ot}.png")
    return pm4py_subnets


def transform_pm4py_subnets_to_qnet(
    pm4py_subnets: Dict[str, Tuple[PetriNet, Marking, Marking]],
    # duplicates: Optional[List[str]] = None,
    handovers: Dict[str, set[str]],
) -> Dict[str, QuantityNet]:
    """
    Transforms object type specific pm4py subnets to QuantityNet objects.
    :param pm4py_subnets: Dictionary with object type as key and tuple of PetriNet, initial marking, and final marking as value.
    :param handovers: (optional) List of transition labels that are considered handovers for particular object types.
    """

    qrpm_subnets = dict()

    for object_type, (net, initial_marking, final_marking) in pm4py_subnets.items():
        t_count = 0
        p_count = 0
        element_identification: Dict[
            str, Transition | Place
        ] = {}  # mapping of name in pm4py net to element in qnet (assuming unique names across places and transitions, which is the case for pm4py)

        transitions_to_add = set()  # Set to collect transitions that need to be added to the qnet
        places_to_add = set()

        ## create transition elements for qnet
        for transition in net.transitions:
            label = transition.label
            if label in handovers[object_type]:
                transition_element = Transition(name=label, label=label, properties={"object_type": object_type})
                transition_element.handover = True
            else:
                transition_name = f"t{t_count}-{object_type}"
                transition_element = Transition(
                    name=transition_name,
                    label=label,
                    properties={"object_type": object_type},
                )
                t_count += 1

            if label:
                if label.startswith(f"{DUMMY_INIT_EVENT}-{object_type}") or label.startswith(
                    f"{DUMMY_FINAL_EVENT}-{object_type}"
                ):
                    transition_element.dummy = True
            element_identification[transition.name] = transition_element
            transitions_to_add.add(transition_element)

        ## create place elements for qnet
        for place in net.places:
            place_name = f"p{p_count}-{object_type}"
            place_element = Place(
                name=place_name,
                object_type=object_type,
                properties={"object_type": object_type},
            )
            if place in initial_marking:
                place_element.initial = True
            if place in final_marking:
                place_element.final = True
            element_identification[place.name] = place_element
            p_count += 1
            places_to_add.add(place_element)

        ## create qnet
        qnet = QuantityNet(name=f"subnet-{object_type}", label=object_type)

        # get Qnet structure of arcs
        for arc in net.arcs:
            source = element_identification[arc.source.name]
            target = element_identification[arc.target.name]
            source.add_output(target)
            target.add_input(source)

        qnet.set_net_structure_with_net_elements(places=places_to_add, transitions=transitions_to_add)
        qrpm_subnets[object_type] = qnet

    return qrpm_subnets


def remove_initialisations_from_subnets(
    sub_qnets: Dict[str, QuantityNet],
) -> Dict[str, QuantityNet]:
    """
    Remove initialisation places and transitions from a QuantityNet.
    For every object type, the process begins with an object of the type *receiving* items.
    So we must remove all places and transitions that do not describe the process but whose only purpose (the only path
    in the graph they are on) is connecting a labelled transition to the initialisation place.
    """

    new_subnets = dict()
    for subnet in sub_qnets.values():
        drop_candindates = list(subnet.get_initial_places())
        while drop_candindates:
            # get next candidate
            node = drop_candindates.pop()

            if isinstance(node, Place):
                if len(node.inputs) > 0:
                    # if place has inputs, keep it
                    continue
                else:
                    # otherwise update candidates with outputs and drop it
                    drop_candindates.extend(list(node.outputs))
                    subnet.remove_place(node)

            elif isinstance(node, Transition):
                if node.silent:
                    # if transition is silent, drop it
                    drop_candindates.extend(list(node.outputs))
                    subnet.remove_transition(node)
                else:
                    # otherwise keep it
                    continue

        new_subnets[subnet.label] = subnet

    return new_subnets


def remove_finalisation_from_subnets(
    sub_qnets: Dict[str, QuantityNet],
) -> Dict[str, QuantityNet]:
    """
    Remove finalisation places and transitions from a QuantityNet.
    For every object type, the process ends with an object of the type *removing* items.
    So we must remove all places and transitions that do not describe the process but whose only purpose (the only path
    in the graph they are on) is connecting a final place to a labelled transition.
    """

    new_subnets = dict()
    for subnet in sub_qnets.values():
        drop_candindates = list(subnet.get_final_places())
        while drop_candindates:
            # get next candidate
            node = drop_candindates.pop(0)

            if isinstance(node, Place):
                if len(node.outputs) > 0:
                    # if place has inputs, keep it
                    continue
                else:
                    # otherwise update candidates with outputs and drop it
                    drop_candindates.extend(list(node.inputs))
                    subnet.remove_place(node)

            elif isinstance(node, Transition):
                if node.silent:
                    # if transition is silent, drop it
                    drop_candindates.extend(list(node.inputs))
                    subnet.remove_transition(node)
                else:
                    # otherwise keep it
                    continue

        new_subnets[subnet.label] = subnet

    return new_subnets


def remove_init_and_final_from_subnets(
    sub_qnets: Dict[str, QuantityNet],
) -> Dict[str, QuantityNet]:
    """
    Remove initialisation and finalisation places and transitions from a QuantityNet.
    """
    removed_init = remove_initialisations_from_subnets(sub_qnets)
    removed_final = remove_finalisation_from_subnets(removed_init)
    return removed_final


def add_handover_input_output_places(
    subnets: Dict[str, QuantityNet],
    handovers: Dict[str, set[str]],
    item_type: Optional[str] = DUMMY_ITEM_TYPE,
):
    """
    Add handover input and output places to the given subnets based on the handover activities.
    """

    extended_subnets = dict()

    for object_type, subnet in subnets.items():
        for handover_activity in handovers[object_type]:
            transition = subnet.get_transition_object(handover_activity)

            if transition is None:
                continue  # then the discovery probably removed the transition due to low frequency

            handover_input = Place(name=f"{DUMMY_INPUT}-{handover_activity}", object_type=item_type)
            subnet.add_place(handover_input)

            if transition.inputs:
                # CREATE AND ADD ADDITIONAL NET ELEMENTS
                # inter-object-type input place

                # object type input transition
                silent_transition = Transition(
                    name=f"{DUMMY_INPUT}-{object_type}-{handover_activity}",
                    label=None,
                    properties={"object_type": object_type},
                    dummy=True,
                )
                silent_transition.silent = True
                subnet.add_transition(silent_transition)

                # connect silent transition to handover input accordingly
                input_places = transition.inputs.copy()
                for place in input_places:
                    # we first remove the connection from the place to the handover activity transition
                    subnet.remove_connection(source=place, target=transition)

                    # then we connect it to the silent transition
                    subnet.add_connection(source=place, target=silent_transition, label=object_type)

                # connect silent transition to handover input
                subnet.add_connection(source=silent_transition, target=handover_input, label=None)

            # connect inter-object-type input place to handover activity transition
            subnet.add_connection(source=handover_input, target=transition, label=None)

            # inter-object-type output place
            handover_output = Place(name=f"{DUMMY_OUTPUT}-{handover_activity}", object_type=item_type)
            subnet.add_place(handover_output)
            if transition.outputs:
                # CREATE AND ADD ADDITIONAL NET ELEMENTS
                # object type input transition
                silent_transition = Transition(
                    name=f"{DUMMY_OUTPUT}-{object_type}-{handover_activity}",
                    label=None,
                    dummy=True,
                    properties={"object_type": object_type},
                )
                silent_transition.silent = True
                subnet.add_transition(silent_transition)

                # connect silent transition to handover outputs accordingly
                output_places = transition.outputs.copy()
                for place in output_places:
                    # we first remove the connection from the place to the handover activity transition
                    subnet.remove_connection(source=transition, target=place)

                    # then we connect it to the silent transition
                    subnet.add_connection(source=silent_transition, target=place, label=object_type)

                # connect handover output to silent transition
                subnet.add_connection(source=handover_output, target=silent_transition, label=None)

            # connect inter-object-type output place to handover activity transition
            subnet.add_connection(source=transition, target=handover_output, label=None)

        extended_subnets[object_type] = subnet
    return extended_subnets


def glue_subnets(extended_subnets: Dict[str, QuantityNet], item_type: Optional[str] = DUMMY_ITEM_TYPE) -> QuantityNet:
    """
    Glue the subnets together into a single QuantityNet.
    """
    element_mapping = dict()  # {name: Place | Transition}
    inputs = dict()  # {name: [input node name, ...]}
    outputs = dict()  # {name: [output node name, ...]}
    new_arc_labels = dict()  # {arc_name: label}
    glued_net = QuantityNet(name=item_type)
    for ot, qnet in extended_subnets.items():
        for (source, target), label in qnet.arc_labels.items():
            new_arc_labels[(source.name, target.name)] = label
        # new_arc_labels.update({(source.name, target.name) for (source, target), label in qnet.arc_labels.items()})

        for place in qnet.places:
            # create new place element
            if place.name in element_mapping.keys():
                pass  # already processed
            else:
                new_place = Place(
                    name=place.name,
                    label=place.label,
                    object_type=place.object_type,
                    properties=place.properties,
                )
                # add to element mapping
                element_mapping[place.name] = new_place

            # add names of inputs and outputs
            if place.name in inputs.keys():
                inputs[place.name].update(place.get_names_of_inputs())
            else:
                inputs[place.name] = place.get_names_of_inputs()

            if place.name in outputs.keys():
                outputs[place.name].update(place.get_names_of_outputs())
            else:
                outputs[place.name] = place.get_names_of_outputs()

            for transition in qnet.transitions:
                # create new transition element
                if transition.name in element_mapping.keys():
                    pass  # already processed
                else:
                    new_transition = Transition(
                        name=transition.name,
                        label=transition.label,
                        handover=transition.handover,
                        dummy=transition.dummy,
                        properties=transition.properties,
                    )
                    # add to element mapping
                    element_mapping[transition.name] = new_transition

                # add names of inputs and outputs
                if transition.name in inputs.keys():
                    inputs[transition.name].update(transition.get_names_of_inputs())
                else:
                    inputs[transition.name] = transition.get_names_of_inputs()

                if transition.name in outputs.keys():
                    outputs[transition.name].update(transition.get_names_of_outputs())
                else:
                    outputs[transition.name] = transition.get_names_of_outputs()

    # add inputs and outputs to elements
    for name, element in element_mapping.items():
        if name in inputs.keys():
            input_elements = [element_mapping[input_name] for input_name in inputs[name]]
            element.inputs = set(input_elements)
        if name in outputs.keys():
            output_elements = [element_mapping[output_name] for output_name in outputs[name]]
            element.outputs = set(output_elements)

        # add element to glued net
        if isinstance(element, Place):
            glued_net.add_place(element)
        elif isinstance(element, Transition):
            glued_net.add_transition(element)
        else:
            raise ValueError(f"Element {element} is neither a Place nor a Transition.")

    # update arc labels with elements
    new_arc_labels = {
        (element_mapping[source_name], element_mapping[target_name]): label
        for (source_name, target_name), label in new_arc_labels.items()
    }

    glued_net.arc_labels = new_arc_labels

    return glued_net

def add_decoupling_points(
    glued_net: QuantityNet,
    decoupling_points: List[QuantityObject],
    item_type: Optional[str] = DUMMY_ITEM_TYPE,
) -> QuantityNet:
    """
    Add decoupling points to the glued net.
    """
    for dp in decoupling_points:
        dp_element = DecouplingPoint(
            name=f"dp-{dp.object_id}",
            label=dp.object_id,
            object_type=dp.object_type,
            dummy = False
        )
        glued_net.add_decoupling_point(dp_element)

        # all adding activities as inputs
        inputs = dp.get_item_type_adding_activities(item_type=item_type)
        for input_activity in inputs:
            handover_transition = glued_net.get_transition_by_name(input_activity)
            if handover_transition is None:
                continue

            silent_dummy_transition = Transition(
                name=f"t-{dp.object_id}-{input_activity}",
                label=None,
                silent=True,
                dummy=True
            )
            glued_net.add_transition(silent_dummy_transition)
            glued_net.add_connection(source=silent_dummy_transition, target=dp_element)
            output_handover = handover_transition.outputs.copy()
            for output_place in output_handover:
                glued_net.add_connection(source=output_place, target=silent_dummy_transition)

        # add removing activities as outputs
        outputs = dp.get_item_type_removing_activities(item_type=item_type)
        for output_activity in outputs:
            handover_transition = glued_net.get_transition_by_name(output_activity)
            if handover_transition is None:
                continue

            silent_dummy_transition = Transition(
                name=f"t-{dp.object_id}-{output_activity}",
                label=None,
                silent=True,
                dummy=True
            )
            glued_net.add_transition(silent_dummy_transition)
            glued_net.add_connection(source=dp_element, target=silent_dummy_transition)
            input_handover = handover_transition.inputs.copy()
            for input_place in input_handover:
                glued_net.add_connection(source=silent_dummy_transition, target=input_place)

    return glued_net


def add_creations_consumptions(
    glued_net: QuantityNet,
    creation_activity_transition_name: List[str],
    consumption_activity_transition_name: List[str],
    item_type: Optional[str] = DUMMY_ITEM_TYPE,
) -> QuantityNet:
    """
    Add creation and consumptions to the glued net.
    """

    for creation_transition_name in creation_activity_transition_name:
        # get transition for creation activity
        transition = glued_net.get_transition_by_name(creation_transition_name)
        if transition is None:
            continue

        dp_element = DecouplingPoint(
            name=f"dp-{DUMMY_INIT_EVENT}-{transition.label}",
            label="",
            object_type=item_type,
            dummy = True
        )
        glued_net.add_decoupling_point(dp_element)

        if transition.inputs:
            # create a silent transition
            silent_transition = Transition(
                name=f"t{DUMMY_INIT_EVENT}-{transition.label}",
                label=f"t{DUMMY_INIT_EVENT}-{transition.label}",
                silent=True,
                dummy=True,
            )

            glued_net.add_transition(silent_transition)

            glued_net.add_connection(source=dp_element, target=silent_transition)

            for place in transition.inputs.copy():
                    glued_net.add_connection(source=silent_transition, target=place)
                    # glued_net.remove_connection(place, transition)
        else:
            glued_net.add_connection(source=dp_element, target=transition)

    for consumption_transition_name in consumption_activity_transition_name:
        # get transition for consumption activity
        transition = glued_net.get_transition_by_name(consumption_transition_name)
        if transition is None:
            continue

        dp_element = DecouplingPoint(
            name=f"dp-{DUMMY_FINAL_EVENT}-{transition.label}",
            object_type=item_type,
            label="",
            dummy=True
        )
        glued_net.add_decoupling_point(dp_element)

        if transition.outputs:
            # create a silent transition
            silent_transition = Transition(
                name=f"t{DUMMY_FINAL_EVENT}-{transition.label}",
                label=f"t{DUMMY_FINAL_EVENT}-{transition.label}",
                silent=True,
                dummy=True,
            )

            # add silent transition to glued net
            glued_net.add_transition(silent_transition)

            # add arc from output place to silent transition
            glued_net.add_connection(silent_transition, dp_element)

            for place in transition.outputs.copy():
                if isinstance(place, Place):
                    # add arc from output place to silent transition
                    glued_net.add_connection(place, silent_transition)
                    # glued_net.remove_connection(transition, place)

        else:
            # add connection
            glued_net.add_connection(transition, dp_element)

    return glued_net
