from datetime import datetime
from typing import List, Dict
from .Qounter import Qounter, MultiQounter


import numpy as np
from pm4py.objects.ocel.obj import OCEL
import pandas as pd
from typing import Any, Iterable, Optional


from uuid import uuid4
from .GLOBAL import (
    PM4PY_OID,
    PM4PY_OBJECT_TYPE,
    PM4PY_TIMESTAMP,
    PM4PY_EID,
    PM4PY_ACTIVITY,
    PM4PY_E2O_QUALIFIER,
    QEL_ITEM_TYPE,
    QEL_QUANTITY,
    TERM_INITIAL,
    TERM_FINAL,
    TERM_INTERMEDIATE,
)


class QuantityEventLog:
    def __init__(
        self,
        ocel: OCEL,
        id: Optional[str] = None,
        oqty: Optional[pd.DataFrame] = None,
        qop: Optional[pd.DataFrame] = None,
    ):
        self._id = id if id is not None else str(uuid4())

        self.ocel = ocel

        ### Optional dataframes for quantity operations and object quantities
        self.oqty: Optional[pd.DataFrame] = (
            pd.DataFrame(columns=[PM4PY_OID, QEL_ITEM_TYPE, QEL_QUANTITY])
            if oqty is None
            else oqty.dropna(subset=[QEL_QUANTITY])
        )
        self.qop: Optional[pd.DataFrame] = (
            pd.DataFrame(columns=[PM4PY_EID, PM4PY_OID, QEL_ITEM_TYPE, QEL_QUANTITY])
            if qop is None
            else qop.dropna(subset=[QEL_QUANTITY])
        )

        # remove null values in oqty and qop
        self.oqty = self.oqty.loc[self.oqty[QEL_QUANTITY] != 0, :]
        self.qop = self.qop.loc[self.qop[QEL_QUANTITY] != 0, :]
        self.ilvl = pd.DataFrame(
            columns=[
                PM4PY_OID,
                PM4PY_EID,
                QEL_ITEM_TYPE,
                QEL_QUANTITY,
                PM4PY_ACTIVITY,
                PM4PY_TIMESTAMP,
            ]
        )

        # initial timestamp for the log
        self.timezone = pd.Timestamp(self.ocel.events[PM4PY_TIMESTAMP].min()).tz
        self.init_time = datetime(1970, 1, 1, 0, 0, 0, 0, tzinfo=self.timezone)

        # log as objects
        self.log_objects = []
        self.log_events = []

        # self.total_ilvl_dataframe()

    @property
    def id(self) -> str:
        return self._id

    # ----- Pm4py Aliases ------------------------------------------------------------------------------------------
    # region

    @property
    def events(self):
        return self.ocel.events

    @property
    def objects(self):
        return self.ocel.objects

    @property
    def object_changes(self):
        return self.ocel.object_changes

    @property
    def e2o(self):
        return self.ocel.relations.sort_values(by=[PM4PY_TIMESTAMP], ascending=[True])

    # endregion
    # ----- BASIC PROPERTIES / STATS ------------------------------------------------------------------------------------------
    # region

    @property
    def activities(self) -> list[str]:
        return list(sorted(self.ocel.events[PM4PY_ACTIVITY].unique().tolist()))

    @property
    def activity_counts(self) -> pd.Series:
        return self.ocel.events[PM4PY_ACTIVITY].value_counts()

    @property
    def object_types(self) -> list[str]:
        return list(sorted(self.ocel.objects[PM4PY_OBJECT_TYPE].unique().tolist()))

    @property
    def otypes(self) -> list[str]:
        """Alias for object_types"""
        return self.object_types

    @property
    def otype_counts(self) -> pd.Series:
        return self.ocel.objects[PM4PY_OBJECT_TYPE].value_counts()

    @property
    def objects_with_otypes(
        self,
    ) -> pd.Series:
        """pandas Series containing the object type of each object"""
        return self.ocel.objects[[PM4PY_OID, PM4PY_OBJECT_TYPE]].set_index(PM4PY_OID)[  # type: ignore
            PM4PY_OBJECT_TYPE
        ]

    @property
    def events_with_activities(self) -> pd.Series:
        """pandas Series containing the activity of each event"""
        return self.ocel.events[
            [PM4PY_EID, PM4PY_ACTIVITY].set_index(PM4PY_EID)[  # type: ignore
                PM4PY_ACTIVITY
            ]
        ]

    @property
    def obj_otypes(self) -> pd.Series:
        """Alias for objects_with_otypes"""
        return self.objects_with_otypes

    @property
    def event_activities(self) -> pd.Series:
        """Alias for events_with_activities"""
        return self.events_with_activities

    def has_object_types(self, otypes: Iterable[str]) -> bool:
        return all(ot in self.otypes for ot in otypes)

    def has_activities(self, activities: Iterable[str]) -> bool:
        return all(act in self.activities for act in activities)

    def earliest_event_timestamp_object(self, object_id) -> pd.Timestamp:
        """
        Returns the earliest timestamp of an event associated with the passed object.
        """
        return self.e2o.loc[self.e2o[PM4PY_OID] == object_id, PM4PY_TIMESTAMP].min()

    def earliest_attribute_timestamp_object(self, object_id) -> pd.Timestamp:
        """
        Returns the earliest timestamp of an object change associated with the passed object.
        """
        return self.object_changes.loc[self.object_changes[PM4PY_OID] == object_id, PM4PY_TIMESTAMP].min()

    def latest_event_timestamp_object(self, object_id) -> pd.Timestamp:
        """
        Returns the latest timestamp of an event associated with the passed object.
        """
        return self.e2o.loc[self.e2o[PM4PY_OID] == object_id, PM4PY_TIMESTAMP].max()

    def latest_attribute_timestamp_object(self, object_id) -> pd.Timestamp:
        """
        Returns the latest timestamp of an object change associated with the passed object.
        """
        return self.object_changes.loc[self.object_changes[PM4PY_OID] == object_id, PM4PY_TIMESTAMP].max()

    def earliest_object_timestamp(self, object_id) -> pd.Timestamp:
        """
        Returns the earliest timestamp of an object, which is the minimum of the earliest event and attribute timestamps. Takes initial timestamp (01.01.1970) into account.
        """

        event_time = self.earliest_event_timestamp_object(object_id)
        attribute_time = self.earliest_attribute_timestamp_object(object_id)

        return min(event_time, attribute_time)

    def latest_object_timestamp(self, object_id) -> pd.Timestamp:
        """
        Returns the latest timestamp of an object, which is the minimum of the earliest event and attribute timestamps. Takes initial timestamp (01.01.1970) into account.
        """

        event_time = self.latest_event_timestamp_object(object_id)
        attribute_time = self.latest_attribute_timestamp_object(object_id)

        return max(event_time, attribute_time)

    def earliest_log_timestamp(self) -> pd.Timestamp:
        """
        Returns the earliest timestamp of the log, which is the minimum of all event and attribute timestamps.
        """
        event_time = self.ocel.events[PM4PY_TIMESTAMP].min()
        attribute_time = self.ocel.object_changes[PM4PY_TIMESTAMP].min()

        return min(event_time, attribute_time)

    def first_events_objects(self):
        """Returns a DataFrame with the first event for each object."""
        return self.e2o.drop_duplicates(subset=[PM4PY_OID], keep="first")

    def last_events_objects(self):
        """Returns a DataFrame with the last event for each object."""
        return self.e2o.drop_duplicates(subset=[PM4PY_OID], keep="last")

    def get_first_event_of_object(self, object_id: Any) -> pd.DataFrame:
        """
        Returns the first event associated with the passed object ID.
        """
        first_event = self.first_events_objects()
        return first_event[first_event[PM4PY_OID] == object_id]

    def get_input_objects(self):
        return self.last_events_objects()

    def get_output_objects(self):
        return self.first_events_objects()

    def get_last_event_of_object(self, object_id: Any) -> pd.DataFrame:
        """
        Returns the last event associated with the passed object ID.
        """
        last_event = self.last_events_objects()
        return last_event[last_event[PM4PY_OID] == object_id]

    def get_final_objects_for_event(self, event_id: Any) -> pd.DataFrame:
        """
        Returns a DataFrame containing all objects where the passed event ID is the final event.
        """
        last_event = self.last_events_objects()
        return last_event[last_event[PM4PY_EID] == event_id]

    def get_initial_objects_for_event(self, event_id: Any) -> pd.DataFrame:
        """
        Returns a DataFrame containing all objects where the passed event ID is the initial event.
        """
        first_event = self.first_events_objects()
        return first_event[first_event[PM4PY_EID] == event_id]

    def get_initial_final_table(self) -> pd.DataFrame:
        """
        Creates a DataFrame containing all event and object combinations where the event is either the first or last event for the object.
        The type of relation is qualified as E2O qualifier.
        Note: The same event can be both the initial and final event for the same object.
        """

        first_events = self.first_events_objects()
        first_events = first_events.drop(columns=[PM4PY_E2O_QUALIFIER])
        first_events.loc[:, PM4PY_E2O_QUALIFIER] = TERM_INITIAL

        last_events = self.last_events_objects()
        last_events = last_events.drop(columns=[PM4PY_E2O_QUALIFIER])
        last_events.loc[:, PM4PY_E2O_QUALIFIER] = TERM_FINAL

        return pd.concat([first_events, last_events])

    def get_unique_e2o_relations(self) -> pd.DataFrame:
        """
        Returns a DataFrame where every e2o relation is present only once. The qualifier column is dropped.
        """
        e2o_new = self.e2o.copy()
        e2o_new = e2o_new.drop(columns=[PM4PY_E2O_QUALIFIER])
        e2o_new = e2o_new.drop_duplicates()
        e2o_new = e2o_new.reset_index(drop=True)
        return e2o_new

    def get_initial_final_qualified_e2o(self) -> pd.DataFrame:
        """
        Returns a DataFrame containing qualified e2o relations where the qualifier informs whether the event it is the initial, final or intermediate event for the object.
        """
        initial_final = self.get_initial_final_table()
        e2o_unique = self.get_unique_e2o_relations()
        e2o_new = e2o_unique.merge(
            initial_final,
            on=[
                PM4PY_OID,
                PM4PY_EID,
                PM4PY_TIMESTAMP,
                PM4PY_ACTIVITY,
                PM4PY_OBJECT_TYPE,
            ],
            how="left",
        )
        e2o_new = e2o_new.fillna({PM4PY_E2O_QUALIFIER: TERM_INTERMEDIATE})
        return e2o_new

    def get_intermediates(self) -> pd.DataFrame:
        """
        Returns a DataFrame containing all objects that are throughput objects for events.
        This is a combination of input and output objects.
        """
        e2o = self.get_initial_final_qualified_e2o()
        return e2o[e2o[PM4PY_E2O_QUALIFIER] == TERM_INTERMEDIATE]

    def get_event_intermediates(self, event_id: Any) -> pd.DataFrame:
        """
        Returns a DataFrame containing all objects that are throughput objects for the passed event ID.
        This is a combination of input and output objects.
        """
        intermediates = self.get_intermediates()
        return intermediates.loc[intermediates[PM4PY_EID] == event_id]

    def get_events_for_object(self, object_id: Any) -> pd.DataFrame:
        """
        Returns a DataFrame containing all events associated with the passed object ID.
        """
        event_ids = self.e2o.loc[self.e2o[PM4PY_OID] == object_id, PM4PY_EID].unique()
        return self.events.loc[self.events[PM4PY_EID].isin(event_ids), :]

    # endregion
    # ----- QEL PROPERTIES / STATS ------------------------------------------------------------------------------------------
    # region

    @property
    def item_types(self) -> list[str]:
        """
        Returns a list of all counted elements appearing in the log (object quantity or quantity operations).
        """
        qty_types_oqty = self.oqty[QEL_ITEM_TYPE].unique().tolist()
        qty_types_qop = self.qop[QEL_ITEM_TYPE].unique().tolist()
        return list(sorted(set(qty_types_oqty + qty_types_qop)))

    # @property
    # def item_types(self) -> list[str]:
    #     """
    #     Returns a list of all item types appearing in the log.
    #     All counted entities that are not object types are considered item types.
    #     """
    #     return [item_type for item_type in self.qty_types if item_type not in self.object_types]

    # @property
    # def item_active_qops(self):
    #     """
    #     Returns a pandas DataFrame containing all quantity operations that are associated with an item type.
    #     """
    #     return self.qop[self.qop[QEL_ITEM_TYPE].isin(self.item_types)]

    # @property
    # def item_active_oqty(self):
    #     """
    #     Returns a pandas DataFrame containing all object quantities that are associated with an item type.
    #     """
    #     return self.oqty[self.oqty[QEL_ITEM_TYPE].isin(self.item_types)]

    @property
    def quantity_active_objects(self) -> List:
        """
        Returns a list of all object IDs that are associated with an item-related quantity operation or object quantity.
        """
        qop_active_objects = self.qop.loc[:, PM4PY_OID].unique()
        oqty_active_objects = self.oqty.loc[:, PM4PY_OID].unique()

        return list(np.unique(np.concatenate((qop_active_objects, oqty_active_objects))))

    def get_active_item_types_for_object(self, object_id) -> List[str]:
        """
        Returns a list of all item types that are associated with the passed object ID.
        This includes item types from both quantity operations and object quantities.
        """
        qop_item_types = self.qop.loc[self.qop[PM4PY_OID] == object_id, QEL_ITEM_TYPE].unique()
        oqty_item_types = self.oqty.loc[self.oqty[PM4PY_OID] == object_id, QEL_ITEM_TYPE].unique()

        return list(np.unique(np.concatenate((qop_item_types, oqty_item_types))))

    def get_item_type_active_objects(self, item_type: str) -> List:
        """
        Returns a list of all object IDs that are associated with a specific item type in quantity operations or object quantities.
        """
        qop_active_objects = self.qop.loc[self.qop[QEL_ITEM_TYPE] == item_type, PM4PY_OID].unique
        oqty_active_objects = self.oqty.loc[self.oqty[QEL_ITEM_TYPE] == item_type, PM4PY_OID].unique

        return list(np.unique(np.concatenate((qop_active_objects, oqty_active_objects))))

    @property
    def quantity_active_events(self) -> List:
        """
        All events that are associated with an active quantity operation.
        """
        return list(self.qop[PM4PY_EID].unique())

    def get_item_type_active_events(self, item_type: str) -> List:
        """
        Returns all events that have at least one active quantity update for the passed item type.
        """
        return list(self.qop.loc[self.qop[QEL_ITEM_TYPE] == item_type, PM4PY_EID].unique())

    def get_oqty_for_object(self, object_id) -> Qounter:
        """
        Returns a Counter object containing the quantities for each item type for a specific object ID.
        """
        oqty = self.oqty.loc[self.oqty[PM4PY_OID] == object_id, :]
        oqty = oqty.set_index(QEL_ITEM_TYPE)
        return Qounter(oqty[QEL_QUANTITY].to_dict())

    def get_oqty_for_object_item_type(self, object_id, item_type):
        """
        Returns the object quantities for passed object ID and item type.
        Returns 0 if no object quantity exists for the passed item type.
        """
        return self.get_oqty_for_object(object_id=object_id)[item_type]

    def get_event_quantity_operations(self, event_id: Any) -> MultiQounter:
        """
        Returns an object containing the quantity operations for all objects that are quantity-active w.r.t. the event.
        Every quantity operation is represented as a Counter object, where the keys are item types and the values are quantities.
        """
        event_quantities = dict()

        event_qups = self.qop.loc[self.qop[PM4PY_EID] == event_id, :]
        active_objects = event_qups[PM4PY_OID].unique()
        for obj in active_objects:
            qop = event_qups[event_qups[PM4PY_OID] == obj]
            qop = qop.set_index(QEL_ITEM_TYPE)
            qop_counter = Qounter(qop[QEL_QUANTITY].to_dict())
            event_quantities[obj] = qop_counter

        return MultiQounter(event_quantities)

    def get_quantity_inputs_outputs_for_all_events(self) -> pd.DataFrame:
        """
        Returns a DataFrame containing one entry per active event-item-type-combination saying how many items were created (positive quantity) or consumed (negative quantity).
        """
        qop = self.qop.copy()
        qop = qop[[PM4PY_EID, QEL_ITEM_TYPE, QEL_QUANTITY]].groupby([PM4PY_EID, QEL_ITEM_TYPE]).sum()
        qop = qop.loc[qop[QEL_QUANTITY] != 0, :].reset_index()
        qop = qop.merge(
            self.events.loc[:, [PM4PY_EID, PM4PY_ACTIVITY, PM4PY_TIMESTAMP]],
            on=PM4PY_EID,
            how="left",
        )

        return qop

    def get_object_qups(self, object_id, item_type) -> pd.DataFrame:
        """
        Returns all quantity updates associated with a specific object ID and item type ordered by time (ascending).
        """
        qops = self.qop[(self.qop[PM4PY_OID] == object_id) & (self.qop[QEL_ITEM_TYPE] == item_type)]
        qops = qops.merge(
            self.events[[PM4PY_EID, PM4PY_ACTIVITY, PM4PY_TIMESTAMP]],
            on=PM4PY_EID,
            how="left",
        )
        qops = qops.sort_values(by=PM4PY_TIMESTAMP, ascending=True)
        return qops

    def post_event_ilvl_dev_object(self, object_id, item_type, all_events: bool = False) -> pd.DataFrame:
        """
        Calculates the item level development for a specific object ID and item type.
        Returns a DataFrame with timestamps and the corresponding item level development.
        Every quantity represents the quantity known AFTER the completion of the quantity operation.
        """

        # get quantity updates & relevant timestamps
        qups = self.qop[(self.qop[PM4PY_OID] == object_id) & (self.qop[QEL_ITEM_TYPE] == item_type)]
        e2o = self.e2o.loc[self.e2o[PM4PY_OID] == object_id, :]

        if all_events:
            qups = e2o.merge(qups, on=[PM4PY_EID, PM4PY_OID], how="left")
            qups = qups.fillna({QEL_ITEM_TYPE: item_type, QEL_QUANTITY: 0})
        else:
            qups = qups.merge(
                self.e2o[
                    [
                        PM4PY_EID,
                        PM4PY_ACTIVITY,
                        PM4PY_TIMESTAMP,
                        PM4PY_OID,
                        PM4PY_OBJECT_TYPE,
                    ]
                ],
                on=[PM4PY_EID, PM4PY_OID],
                how="left",
            )

        # get initial value
        init = self.get_oqty_for_object_item_type(object_id, item_type=item_type)

        # create table with timestamps and quantity values
        if qups.empty:
            start_ilvl = pd.DataFrame(
                {
                    PM4PY_TIMESTAMP: [self.init_time],
                    QEL_QUANTITY: [init],
                    PM4PY_EID: np.nan,
                    PM4PY_ACTIVITY: np.nan,
                }
            )
            # if no qups exist, the initial value is set at the earliest timestamp and the final value at the latest timestamp
            return start_ilvl
        else:
            pass

        initial_entry = pd.DataFrame({PM4PY_TIMESTAMP: [self.init_time], QEL_QUANTITY: [init]})
        deltas = pd.concat([initial_entry, qups], ignore_index=True)

        # determine item_level_development
        deltas = deltas.sort_values(by=[PM4PY_TIMESTAMP], ascending=[True])
        item_level_development = deltas.copy()
        item_level_development[QEL_QUANTITY] = item_level_development[QEL_QUANTITY].cumsum()

        return item_level_development

    def get_ilvls_for_object(self, object_id, all_events: bool = False) -> Dict[Any, pd.DataFrame]:
        """
        Returns a dictionary of DataFrames for each item type associated with the passed object ID.
        The keys are the item types and the values are the DataFrames representing the item level development.
        """
        ilvls = dict()
        item_types = self.get_active_item_types_for_object(object_id)

        for item_type in item_types:
            ilvl_dev = self.post_event_ilvl_dev_object(object_id, item_type, all_events)
            ilvls[item_type] = ilvl_dev

        return ilvls

    def set_qel_ilvl(self):
        self.ilvl = self.get_total_ilvl_dataframe(all_events=True)

    def get_total_ilvl_dataframe(self, all_events: bool = False):
        """
        Determine dataframe with item level development for all objects and item types.
        """
        ilvl = pd.DataFrame()
        for obj in self.objects[PM4PY_OID].unique():
            ilvls = self.get_ilvls_for_object(obj, all_events=all_events)
            for item_type, ilvl_dev in ilvls.items():
                ilvl_dev[PM4PY_OID] = obj
                ilvl_dev[QEL_ITEM_TYPE] = item_type
                ilvl = pd.concat([ilvl, ilvl_dev], ignore_index=True)

        return ilvl

    def determine_item_type_active_e2o_relations(self, item_type: str) -> pd.DataFrame:
        """
        Returns a DataFrame containing all e2o relations where the item type is active.
        This includes both initial and final events for the item type.
        """
        ilvl = self.get_total_ilvl_dataframe(all_events=True)
        ilvl = ilvl[ilvl[QEL_ITEM_TYPE] == item_type]
        ilvl = ilvl.sort_values(by=[PM4PY_TIMESTAMP], ascending=[True])

        it_active_overview = pd.DataFrame()
        for object_id in ilvl[PM4PY_OID].unique():
            ilvl_object = ilvl.loc[ilvl[PM4PY_OID] == object_id, :]

            # it-active if the quantity is greater than 0 after the event
            ilvl_object.loc[ilvl_object[QEL_QUANTITY] > 0, f"{item_type}_active"] = True
            # it-active if quantity before the event is greater than 0
            ilvl_object.loc[ilvl_object[QEL_QUANTITY].shift(1) > 0, f"{item_type}_active"] = True

            it_active_overview = pd.concat([it_active_overview, ilvl_object], ignore_index=True)

        it_active_overview = it_active_overview.fillna({f"{item_type}_active": False})

        return it_active_overview
