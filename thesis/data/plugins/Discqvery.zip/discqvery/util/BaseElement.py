import uuid


class BaseElement:
    def __init__(self, name: any = None, label: str = None, properties: dict = None):
        self._id = uuid.uuid4()
        self._name = name if name else self.id
        self._label = label if label else None
        self._properties = properties if properties else None

    def __str__(self):
        return self.name

    def __repr__(self):
        return f"{self.name} ({type(self).__name__})"

    @property
    def id(self):
        return self._id

    @property
    def name(self):
        return self._name

    @property
    def properties(self):
        return self._properties

    @id.setter
    def id(self, id):
        self._id = id

    @name.setter
    def name(self, name):
        self._name = name

    @property
    def label(self):
        return self._label

    @label.setter
    def label(self, label):
        self._label = label

    @properties.setter
    def properties(self, properties):
        self._properties = properties


class ConnectingElement(BaseElement):
    def __init__(self, source, target, name=None, label: str = None, properties: dict = None):
        super().__init__(name=name, label=label, properties=properties)
        self._source = source
        self._target = target

    @property
    def source(self):
        return self._source

    @property
    def target(self):
        return self._target

    @source.setter
    def source(self, source):
        self._source = source

    @target.setter
    def target(self, target):
        self._target = target


class ConnectedElement(BaseElement):
    def __init__(self, name, label: str = None, properties: dict = None):
        super().__init__(name=name, label=label, properties=properties)
        self._inputs = set()
        self._outputs = set()

    @property
    def inputs(self):
        """
        Returns a set of all input elements.
        """
        return self._inputs

    @inputs.setter
    def inputs(self, inputs: set["ConnectedElement"]):
        if isinstance(inputs, (set, list, tuple)):
            self._inputs = set(inputs)
        else:
            raise ValueError("Inputs must be a set of ConnectedElement objects.")

    @property
    def outputs(self):
        """
        Returns a set of all output elements.
        """
        return self._outputs

    @outputs.setter
    def outputs(self, outputs: set["ConnectedElement"]):
        if isinstance(outputs, (set, list, tuple)):
            self._outputs = set(outputs)
        else:
            raise ValueError("Outputs must be a set of ConnectedElement objects.")

    # def get_input_arcs(self) -> set[ConnectingElement]:
    #     """
    #     Returns a set of all input arcs connected to this element.
    #     """
    #     return {ConnectingElement(source=input_node, target=self, name=f"{input_node} -> {self.name}")
    #             for input_node in self.inputs}
    #
    # def get_output_arcs(self) -> set[ConnectingElement]:
    #     """
    #     Returns a set of all output arcs connected to this element.
    #     """
    #     return {ConnectingElement(source=self, target=output_node, name=f"{self.name} -> {output_node}")
    #             for output_node in self.outputs}

    # def add_input(self, input_element: "ConnectedElement"):
    #     """
    #     Adds an input element to this connected element.
    #     """
    #     if isinstance(input_element, self.__class__):
    #         self.inputs.add(input_element)
    #     else:
    #         raise ValueError("Input must be a ConnectedElement object.")
    #
    # def add_output(self, output_element: "ConnectedElement"):
    #     """
    #     Adds an output element to this connected element.
    #     """
    #     if isinstance(output_element, self.__class__):
    #         self.outputs.add(output_element)
    #     else:
    #         raise ValueError("Output must be a ConnectedElement object.")

    def get_connected_nodes(self) -> set["ConnectedElement"]:
        """
        Returns a set of all connected nodes (both inputs and outputs).
        """
        return self.inputs | self.outputs

    def get_name_of_connected_nodes(self) -> set[str]:
        """
        Returns a set of names of all connected nodes (both inputs and outputs).
        """
        return {node.name for node in self.get_connected_nodes()}

    def get_names_of_inputs(self) -> set[str]:
        """
        Returns a set of names of all input nodes.
        """
        return {input_node.name for input_node in self.inputs}

    def get_names_of_outputs(self) -> set[str]:
        """
        Returns a set of names of all output nodes.
        """
        return {output_node.name for output_node in self.outputs}

    def remove_input(self, input_element: "ConnectedElement"):
        """
        Removes an input element from this connected element.
        """
        self.inputs.discard(input_element)

    def remove_output(self, output_element: "ConnectedElement"):
        """
        Removes an output element from this connected element.
        """
        self.outputs.discard(output_element)

    def remove_connected_node(self, node: "ConnectedElement"):
        """
        Removes a connected node (either input or output) from this connected element.
        """
        if node in self.inputs:
            self.remove_input(node)
        if node in self.outputs:
            self.remove_output(node)

    def get_connected_node_by_name(self, node_name: str) -> "ConnectedElement":
        """
        Returns a connected node by its name from this connected element.
        """
        for node in self.get_connected_nodes():
            if node.name == node_name:
                return node
        return None

    def remove_connected_node_by_name(self, node_name: str):
        """
        Removes a connected node by its name from this connected element.
        """
        node = self.get_connected_node_by_name(node_name)
        if node:
            self.remove_connected_node(node)

    # @property
    # def arcs(self):
    #     return self.input_arcs | self.output_arcs
    #
    # @property
    # def input_arcs(self) -> set:
    #     return self._input_arcs
    #
    # @property
    # def output_arcs(self):
    #     return self._output_arcs
    #
    # @input_arcs.setter
    # def input_arcs(self, input_arcs: set[ConnectingElement]):
    #     self._input_arcs = input_arcs
    #
    # @output_arcs.setter
    # def output_arcs(self, output_arcs: set[ConnectingElement]):
    #     self._output_arcs = output_arcs
    #
    # @property
    # def inputs(self):
    #     """
    #     set of all input elements
    #     """
    #     return set([arc.source for arc in self.input_arcs if isinstance(arc.source, ConnectedElement)])
    #
    # @property
    # def outputs(self):
    #     """
    #     set of all output elements
    #     """
    #     return set([arc.target for arc in self.output_arcs if isinstance(arc.target, ConnectedElement)])
    #
    # @property
    # def connected(self) -> bool:
    #     """
    #     Returns True if the element has at least one input or output arc.
    #     """
    #     return (len(self.input_arcs) > 0) or (len(self.output_arcs) > 0)
    #
    # def add_input_arc(self, arc: ConnectingElement):
    #     if isinstance(arc, ConnectingElement) and not isinstance(arc.source, type(arc.target)):
    #         if self == arc.target:
    #             self._input_arcs.add(arc)
    #         else:
    #             raise ValueError("Only arcs connected to the elements itsself can be added as input arcs.")
    #     else:
    #         raise ValueError(
    #             "Input arcs must be connecting elements and the source and target must be of different types.")
    #
    # def add_output_arc(self, arc: ConnectingElement):
    #     if isinstance(arc, ConnectingElement) and type(arc.source) is not type(arc.target):
    #         if self == arc.source:
    #             self._output_arcs.add(arc)
    #         else:
    #             raise ValueError("Only arcs connected to the elements itsself can be added as output arcs.")
    #     else:
    #         raise ValueError(
    #             "Output arcs must be connecting elements and the source and target must be of different types.")
    #
    # def remove_input_arc(self, arc: ConnectingElement):
    #     self._input_arcs.discard(arc)
    #
    # def remove_output_arc(self, arc: ConnectingElement):
    #     self._output_arcs.discard(arc)
