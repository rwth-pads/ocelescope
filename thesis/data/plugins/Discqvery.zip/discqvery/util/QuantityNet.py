from collections.abc import Iterable

from .BaseElement import BaseElement
from .NetElements import Arc, Place, Transition, DecouplingPoint


class QuantityNet(BaseElement):
    def __init__(
        self,
        name,
        label: str = None,
        properties: dict = None,
        places: set[Place] = None,
        transitions: set[Transition] = None,
        decoupling_points: set[DecouplingPoint] = None,
    ):
        super().__init__(name=name, label=label, properties=properties)
        self._places = set()
        self._transitions = set()
        self._decoupling_points = set()
        if places is not None:
            self.places = places
        if transitions is not None:
            self.transitions = transitions
        if decoupling_points is not None:
            self._decoupling_points = decoupling_points
        self.arc_labels: dict[tuple[Place | Transition | DecouplingPoint, Place | Transition | DecouplingPoint], str] = dict()  # {(source, target): label}

    @property
    def places(self):
        return self._places

    @places.setter
    def places(self, places: set[Place]):
        if isinstance(places, (set, list, tuple)):
            if all(isinstance(element, Place) for element in places):
                self._places = places
            else:
                raise ValueError("Passed places must be a set of Place objects.")
        else:
            raise ValueError("Passed places must be a set of Place objects.")

    @property
    def object_types(self):
        return {place.object_type for place in self.places}

    @property
    def labelled_transitions(self):
        return {transition for transition in self.transitions if not transition.silent}

    @property
    def nodes(self):
        return self._places | self._transitions

    @property
    def transitions(self):
        return self._transitions

    @transitions.setter
    def transitions(self, transitions: set[Transition]):
        if isinstance(transitions, (set, list, tuple)):
            if all(isinstance(element, Transition) for element in transitions):
                self._transitions = transitions
            else:
                raise ValueError("Passed transitions must be a set of Transition objects.")
        else:
            raise ValueError("Passed transitions must be a set of Transition objects.")

    @property
    def decoupling_points(self):
        return self._decoupling_points

    @decoupling_points.setter
    def decoupling_points(self, decoupling_points: set[DecouplingPoint]):
        if isinstance(decoupling_points, (set, list, tuple)):
            if all(isinstance(element, DecouplingPoint) for element in decoupling_points):
                self._decoupling_points = decoupling_points
            else:
                raise ValueError("Passed decoupling points must be a set of DecouplingPoint objects.")

    def get_transition_names(self):
        """
        Returns a set of names of all transitions in the QuantityNet.
        """
        return {transition.name for transition in self.transitions}

    def get_place_names(self):
        """
        Returns a set of names of all places in the QuantityNet.
        """
        return {place.name for place in self.places}

    def get_dp_names(self):
        """
        Returns a set of names of all decoupling points in the QuantityNet.
        """
        return {dp.name for dp in self.decoupling_points}

    def get_arcs(self):
        arcs = set()
        for transition in self.transitions:
            for place in transition.inputs:
                if isinstance(place, Place):
                    pass
                else:
                    continue

                if place in self.places:
                    pass
                else:
                    transition.remove_input(place)

                if place in transition.get_variable_input_places():
                    variable = True
                else:
                    variable = False

                if (place, transition) in self.arc_labels:
                    arc_label = self.arc_labels[(place, transition)]
                else:
                    arc_label = None

                arcs.add(
                    Arc(
                        source=place,
                        target=transition,
                        variable=variable,
                        label=arc_label,
                    )
                )

            for place in transition.outputs:
                if isinstance(place, Place):
                    pass
                else:
                    continue

                if place in self.places:
                    pass
                else:
                    transition.remove_output(place)

                if place in transition.get_variable_output_places():
                    variable = True
                else:
                    variable = False

                if (transition, place) in self.arc_labels:
                    arc_label = self.arc_labels[(transition, place)]
                else:
                    arc_label = None

                arcs.add(
                    Arc(
                        source=transition,
                        target=place,
                        variable=variable,
                        label=arc_label,
                    )
                )

            for dp in transition.inputs:
                if isinstance(dp, DecouplingPoint):
                    pass
                else:
                    continue

                if dp in self.decoupling_points:
                    pass
                else:
                    transition.remove_input(dp)

                if (dp, transition) in self.arc_labels:
                    arc_label = self.arc_labels[(dp, transition)]
                else:
                    arc_label = None

                arcs.add(
                    Arc(
                        source=dp,
                        target=transition,
                        variable=False,
                        label=arc_label,
                    )
                )

            for dp in transition.outputs:
                if isinstance(dp, DecouplingPoint):
                    pass
                else:
                    continue

                if dp in self.decoupling_points:
                    pass
                else:
                    transition.remove_output(dp)

                if (transition, dp) in self.arc_labels:
                    arc_label = self.arc_labels[(transition, dp)]
                else:
                    arc_label = None

                arcs.add(
                    Arc(
                        source=transition,
                        target=dp,
                        variable=False,
                        label=None,
                    )
                )

        return arcs

    def get_variable_arcs(self):
        return {arc for arc in self.get_arcs() if arc.variable}

    def get_transition_labels(self):
        return {transition: transition.label for transition in self.transitions if transition.label}

    def get_place_mapping(self):
        return {place: place.object_type for place in self.places}

    def get_silent_transitions(self):
        return {transition for transition in self.transitions if transition.silent}

    def get_marking(self):
        return {place: place.marking for place in self.places}

    def get_transition_by_name(self, name: str) -> Transition | None:
        """
        Returns a Transition object by its name.
        """
        for transition in self.transitions:
            if transition.name == name:
                return transition
        else:
            return None

    def get_transition_by_label(self, label: str) -> Transition | None:
        """
        Returns a Transition object by its label.
        """
        for transition in self.transitions:
            if transition.label == label:
                return transition
        else:
            return None

    def get_transition_object(self, string: str) -> Transition | None:
        """
        Returns a Transition object by its name or label.
        """
        transition = self.get_transition_by_name(string)
        if transition is not None:
            return transition
        return self.get_transition_by_label(string)

    def get_place_by_name(self, name: str) -> Place | None:
        """
        Returns a Place object by its name.
        """
        for place in self.places:
            if place.name == name:
                return place
        else:
            return None

    def get_dp_by_name(self, name: str) -> DecouplingPoint | None:
        """
        Returns a Place object by its name.
        """
        for dp in self.decoupling_points:
            if dp.name == name:
                return dp
        else:
            return None

    def set_net_structure_with_net_elements(self, transitions: Iterable[Transition], places: Iterable[Place]):
        """
        Set the net structure with a set of Arc objects where each Arc connects a Place and a Transition.
        Removes any existing arcs, places, and transitions before setting the new structure.
        """
        self.places = set(places)
        self.transitions = set(transitions)

    def get_initial_places(self) -> set[Place]:
        """
        Returns a set of initial places in the QuantityNet.
        """
        return {place for place in self.places if place.initial}

    def get_final_places(self) -> set[Place]:
        """
        Returns a set of final places in the QuantityNet.
        """
        return {place for place in self.places if place.final}

    def remove_transition(self, transition: Transition | str):
        """
        Removes a transition from the QuantityNet.
        """
        # remove the transition itself
        if isinstance(transition, str):
            transition = self.get_transition_by_name(transition)
        elif not isinstance(transition, Transition):
            raise ValueError("Transition must be a Transition object or a string representing the transition name.")

        self._transitions.discard(transition)

        # remove transition from all places it is connected to
        for place in self.places:
            place.remove_connected_node_by_name(transition.name)

    def remove_place(self, place: Place | str):
        """
        Removes a transition from the QuantityNet.
        """
        # remove the transition itself
        if isinstance(place, str):
            place = self.get_place_by_name(place)
        elif not isinstance(place, Place):
            raise ValueError("Transition must be a Transition object or a string representing the transition name.")

        self._places.discard(place)

        # remove transition from all places it is connected to
        for transition in self.transitions:
            transition.remove_connected_node_by_name(place.name)

    def get_node_by_name(self, name: str) -> Place | Transition | DecouplingPoint| None:
        """
        Returns a Place or Transition object by its name.
        """
        node = self.get_place_by_name(name)
        if node is not None:
            return node
        elif (self.get_dp_by_name(name)) is not None:
            return self.get_dp_by_name(name)
        return self.get_transition_by_name(name)

    def remove_connection(self, source: Place | Transition | str, target: Place | Transition | str):
        """
        Removes a connection (arc) between a source and a target element in the QuantityNet.
        """
        if isinstance(source, str):
            source = self.get_node_by_name(source)
        if isinstance(target, str):
            target = self.get_node_by_name(target)

        if not isinstance(source, (Place, Transition, DecouplingPoint)) or not isinstance(target, (Place, Transition, DecouplingPoint)):
            raise ValueError("Source and target must be either Place, Decoupling Point or Transition objects.")

        source.remove_output(target)
        target.remove_input(source)

    def add_connection(
        self,
        source: Place | Transition | DecouplingPoint | str,
        target: Place | Transition | DecouplingPoint | str,
        label: str | None = None,
    ):
        """
        Adds a new connection (arc) between a source and a target element in the QuantityNet.
        """
        if isinstance(source, str):
            source = self.get_node_by_name(source)
        if isinstance(target, str):
            target = self.get_node_by_name(target)

        if not isinstance(source, (Place, DecouplingPoint, Transition)) or not isinstance(target, (Place, DecouplingPoint, Transition)):
            raise ValueError(
                "Source and target must be either Place or Transition objects and they must both be part of the net."
            )

        source.add_output(target)
        target.add_input(source)

        if label is not None:
            self.arc_labels[(source, target)] = label

    def add_place(self, new_place: Place):
        """
        Adds a new place to the QuantityNet.
        """
        if not isinstance(new_place, Place):
            raise ValueError("Place must be a Place object.")

        # check if the place already exists in the net
        if new_place.name in self.get_place_names():
            # merge the inputs and outputs of the existing place with the new one
            existing_place = self.get_place_by_name(new_place.name)
            existing_place.inputs.update(new_place.inputs)
            existing_place.outputs.update(new_place.outputs)
            # TODO: handle the marking and other properties if necessary
            # for now, we just keep the existing marking
        else:
            self.places.add(new_place)

    def add_decoupling_point(self, new_dp: DecouplingPoint):
        """
        Adds a new place to the QuantityNet.
        """
        if not isinstance(new_dp, DecouplingPoint):
            raise ValueError("Decoupling Point must be Decoupling Point object.")

        # check if the place already exists in the net
        if new_dp.name in self.get_dp_names():
            # merge the inputs and outputs of the existing place with the new one
            existing_dp = self.get_dp_by_name(new_dp.name)
            existing_dp.inputs.update(new_dp.inputs)
            existing_dp.outputs.update(new_dp.outputs)
            # TODO: handle the marking and other properties if necessary
            # for now, we just keep the existing marking
        else:
            self.decoupling_points.add(new_dp)

    def add_transition(self, new_transition: Transition):
        """Adds a new transition to the QuantityNet."""
        if not isinstance(new_transition, Transition):
            raise ValueError("Transition must be a Transition object.")

        if new_transition.name in self.get_transition_names():
            # merge the inputs and outputs of the existing transition with the new one
            existing_transition = self.get_transition_by_name(new_transition.name)
            existing_transition.inputs.update(new_transition.inputs)
            existing_transition.outputs.update(new_transition.outputs)
            existing_transition.variable_places.update(new_transition.variable_places)
        else:
            self.transitions.add(new_transition)

    # def get_handover_transitions(self) -> set[Transition]:
    #     """
    #     Returns a set of transitions that are marked as handover transitions.
    #     """
    #     return {transition for transition in self.transitions if transition.handover}

    def remove_inputs_outputs_not_in_net(self):
        """
        Removes inputs and outputs that are not part of the net.
        This is useful to clean up the net structure after modifications.
        """
        for transition in self.transitions:
            transition.inputs = {place for place in transition.inputs if place in self.places}
            transition.outputs = {place for place in transition.outputs if place in self.places}

        for place in self.places:
            place.inputs = {transition for transition in place.inputs if transition in self.transitions}
            place.outputs = {transition for transition in place.outputs if transition in self.transitions}

    def remove_unshared_connections(self):
        """
        Removes connections (arcs) that are not shared between places and transitions.
        This is useful to clean up the net structure after modifications.
        """
        for transition in self.transitions:
            transition.inputs = {place for place in transition.inputs if transition in place.outputs}
            transition.outputs = {place for place in transition.outputs if transition in place.inputs}

        for place in self.places:
            place.inputs = {transition for transition in place.inputs if place in transition.outputs}
            place.outputs = {transition for transition in place.outputs if place in transition.inputs}

    def clean_qnet_structure(self):
        """
        Cleans the QuantityNet structure by removing inputs and outputs not in the net,
        and removing unshared connections.
        """
        self.remove_inputs_outputs_not_in_net()
        self.remove_unshared_connections()
