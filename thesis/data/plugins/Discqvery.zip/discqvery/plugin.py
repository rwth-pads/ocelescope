from typing import Annotated

from ocelescope import OCEL, OCELAnnotation, Plugin, plugin_method

from .extensions.quantity import QuantityExtension
from .inputs.discover_qnet import DiscoverQnetInput
from .resources.qnet import QNet
from .util.utils import (
    add_creations_consumptions,
    add_decoupling_points,
    add_handover_input_output_places,
    discover_subnets,
    glue_subnets,
    remove_init_and_final_from_subnets,
    transform_pm4py_subnets_to_qnet,
)


class Discqvery(Plugin):
    label = "Discqvery"
    description = "A proof of concept for working with extended OCELs in plugins."
    version = "0.1.0"

    @plugin_method(
        label="Discover Quantity Net",
        description="Proof of concept for using extended OCELs in plugins; current results are incomplete.",
    )
    def discover_qnet(
        self,
        ocel: Annotated[
            OCEL,
            OCELAnnotation(
                label="Event Log", description="A petri net enriched with quantity states", extension=QuantityExtension
            ),
        ],
        input: DiscoverQnetInput,
    ) -> QNet:
        item_type = input.item_type
        ext = ocel.get_extension(QuantityExtension)
        if ext is None:
            raise KeyError("Extension could not be found")

        qel = ext.discover_qel()

        qel.prepare_traces_for_item_type_discovery(item_type=item_type)

        pm4py_subnets = discover_subnets(qel, show_nets=False, export_subnets=False)

        handovers = qel.get_item_type_active_types(item_type=item_type)
        sub_qnets = transform_pm4py_subnets_to_qnet(pm4py_subnets, handovers=handovers)

        new_subnets = remove_init_and_final_from_subnets(sub_qnets)

        extended_subnets = add_handover_input_output_places(
            new_subnets, handovers=qel.get_item_type_active_types(item_type=item_type), item_type=item_type
        )

        glued_net = glue_subnets(sub_qnets, item_type=item_type)

        # add decoupling points
        decoupling_points = qel.get_decoupling_points()
        glued_net = add_decoupling_points(glued_net, decoupling_points, item_type=item_type)

        # add creation and consumption places to the glued net
        creation_activity_transition_name = qel.get_creation_activities(item_type=item_type)
        consumption_activity_transition_name = qel.get_consumption_activities(item_type=item_type)

        glued_net = add_creations_consumptions(
            glued_net, creation_activity_transition_name, consumption_activity_transition_name, item_type=item_type
        )

        qnet = QNet.from_legacy_net(qnet=glued_net, item_type=item_type)

        return qnet
