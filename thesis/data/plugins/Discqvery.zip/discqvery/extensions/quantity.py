import xml.etree.ElementTree as etree

import pandas as pd
from ocelescope import OCEL, OCELExtension

from ..util.disqovery import (
    DisqoveryQEL,
    QuantityEvent,
    QuantityObject,
    Trace,
    TraceEntry,
)
from ..util.GLOBAL import (
    PM4PY_ACTIVITY,
    PM4PY_EID,
    PM4PY_OBJECT_TYPE,
    PM4PY_OID,
    PM4PY_TIMESTAMP,
    QEL_ITEM_TYPE,
    QEL_QUANTITY,
    XML_QUANTITY_EXTENSION,
)
from ..util.io import read_extension_from_xml, write_extension_to_xml
from ..util.Qounter import MultiQounter, Qounter


class QuantityExtension(
    OCELExtension,
):
    name = "Quantinty Logs"
    description = "Whatever this is doing"
    version = "1.0"
    supported_extensions = [".xmlocel"]

    def __init__(
        self,
        ocel: OCEL,
        oqty: pd.DataFrame | None = None,
        qop: pd.DataFrame | None = None,
    ):
        self.ocel = ocel
        self.oqty: pd.DataFrame | None = (
            pd.DataFrame(columns=[PM4PY_OID, QEL_ITEM_TYPE, QEL_QUANTITY])
            if oqty is None
            else oqty.dropna(subset=[QEL_QUANTITY])
        )
        self.qop: pd.DataFrame | None = (
            pd.DataFrame(columns=[PM4PY_EID, PM4PY_OID, QEL_ITEM_TYPE, QEL_QUANTITY])
            if qop is None
            else qop.dropna(subset=[QEL_QUANTITY])
        )

        # remove null values in oqty and qop
        self.oqty = self.oqty.loc[self.oqty[QEL_QUANTITY] != 0, :]
        self.qop = self.qop.loc[self.qop[QEL_QUANTITY] != 0, :]
        self.ilvl = pd.DataFrame(
            columns=[
                PM4PY_OID,
                PM4PY_EID,
                QEL_ITEM_TYPE,
                QEL_QUANTITY,
                PM4PY_ACTIVITY,
                PM4PY_TIMESTAMP,
            ]
        )

        # log as objects
        self.log_objects = []
        self.log_events = []

        # self.total_ilvl_dataframe()

        return

    # Methods from OCELExtension
    @staticmethod
    def has_extension(path):
        tree = etree.parse(path)
        root = tree.getroot()
        return root.find(XML_QUANTITY_EXTENSION) is not None

    @classmethod
    def import_extension(cls, ocel, path):
        oqty, qop = read_extension_from_xml(path)
        return cls(ocel, oqty=oqty, qop=qop)

    def export_extension(self, path):
        write_extension_to_xml(path=path, oqty=self.oqty, qop=self.qop)  # type: ignore
        return

    def get_events_for_object(self, object_id: str) -> pd.DataFrame:
        """
        Returns a DataFrame containing all events associated with the passed object ID.
        """
        event_ids = self.ocel.relations.loc[self.ocel.relations[PM4PY_OID] == object_id, PM4PY_EID].unique()
        return self.ocel.events.loc[self.ocel.events[PM4PY_EID].isin(event_ids), :]

    def get_event_quantity_operations(self, event_id: str) -> MultiQounter:
        """
        Returns an object containing the quantity operations for all objects that are quantity-active w.r.t. the event.
        Every quantity operation is represented as a Counter object, where the keys are item types and the values are quantities.
        """
        event_quantities = dict()

        event_qups = self.qop.loc[self.qop[PM4PY_EID] == event_id, :]
        active_objects = event_qups[PM4PY_OID].unique()
        for obj in active_objects:
            qop = event_qups[event_qups[PM4PY_OID] == obj]
            qop = qop.set_index(QEL_ITEM_TYPE)
            qop_counter = Qounter(qop[QEL_QUANTITY].to_dict())
            event_quantities[obj] = qop_counter

        return MultiQounter(event_quantities)

    def get_oqty_for_object(self, object_id) -> Qounter:
        """
        Returns a Counter object containing the quantities for each item type for a specific object ID.
        """
        oqty = self.oqty.loc[self.oqty[PM4PY_OID] == object_id, :]
        oqty = oqty.set_index(QEL_ITEM_TYPE)
        return Qounter(oqty[QEL_QUANTITY].to_dict())

    def discover_qel(self):
        event_elements = dict()

        for _, event in self.ocel.events.iterrows():
            event_elements[event[PM4PY_EID]] = QuantityEvent(
                event_id=event[PM4PY_EID],
                activity=event[PM4PY_ACTIVITY],
                timestamp=event[PM4PY_TIMESTAMP],
                event_qops=self.get_event_quantity_operations(event[PM4PY_EID]),
            )

        qbjects = []

        for index, obj in self.ocel.objects.iterrows():
            object_id = obj[PM4PY_OID]

            qo = QuantityObject(
                object_id=object_id,
                object_type=obj[PM4PY_OBJECT_TYPE],
                init_ilvl=self.get_oqty_for_object(object_id),
            )
            trace = Trace()
            obj_event = self.get_events_for_object(object_id).sort_values(by=[PM4PY_TIMESTAMP], ascending=True)
            # print(obj_event)
            for ev in obj_event[PM4PY_EID].unique():
                # update quantity operations for event
                ev_element = event_elements[ev]
                # create trace entry
                trace_entry = TraceEntry(event=ev_element, qop=ev_element[object_id])
                trace.append(trace_entry)

            # add trace to quantity object
            qo.add_trace(trace)

            # add quantity object to list
            qbjects.append(qo)

        return DisqoveryQEL(qbjects, list(event_elements.values()))
